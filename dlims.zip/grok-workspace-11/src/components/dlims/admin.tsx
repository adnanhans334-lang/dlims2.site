import { useEffect, useState, type FormEvent } from "react";
import {
  ADMIN_USER,
  blankLicense,
  loadSharedDesk,
  logout,
  readSharedStamp,
  removeLicense,
  saveLicense,
  setAccountFee,
  setAccountStatus,
  setLicenseFee,
  updateRequest,
  useDB,
  useSession,
  type LicenseRecord,
} from "@/components/dlims/store";

const input = "w-full rounded-lg border border-line bg-white px-3 py-2 text-sm";

type Panel = "requests" | "live" | "ecard" | "regular" | "edit" | "status" | "fee" | "learner";

const PANELS: { id: Panel; label: string }[] = [
  { id: "requests", label: "Requests" },
  { id: "live", label: "Live" },
  { id: "ecard", label: "E-Card" },
  { id: "regular", label: "Regular" },
  { id: "edit", label: "Edit" },
  { id: "status", label: "Status" },
  { id: "fee", label: "Fee" },
  { id: "learner", label: "Learner" },
];

function readUpload(file: File, done: (url: string) => void) {
  if (file.type === "application/pdf") {
    const reader = new FileReader();
    reader.onload = () => done(String(reader.result || ""));
    reader.readAsDataURL(file);
    return;
  }
  readImage(file, done);
}

function readImage(file: File, done: (url: string) => void) {
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, 900 / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
      done(canvas.toDataURL("image/jpeg", 0.72));
    };
    img.src = String(reader.result || "");
  };
  reader.readAsDataURL(file);
}

export function AdminDesk({ onLeave }: { onLeave: () => void }) {
  const session = useSession();
  const db = useDB();
  const [panel, setPanel] = useState<Panel>("requests");
  const [editing, setEditing] = useState<LicenseRecord | null>(null);
  const [sharedNote, setSharedNote] = useState("Connecting live sync...");

  useEffect(() => {
    if (!session || session.role !== "admin") return;
    let live = true;
    let stamp = "";
    const tick = async () => {
      try {
        const next = await readSharedStamp();
        if (!live) return;
        const key = JSON.stringify(next);
        if (key === stamp) return;
        stamp = key;
        await loadSharedDesk();
        if (live) setSharedNote("Live sync on. A change here shows on other phones within a few seconds.");
      } catch {
        if (live) setSharedNote("Live sync paused. This phone still has the last copy.");
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 4000);
    return () => {
      live = false;
      window.clearInterval(id);
    };
  }, [session]);

  if (!session || session.role !== "admin") {
    return (
      <div className="mx-auto max-w-md rounded-2xl bg-white p-6 text-center">
        <p className="font-black">This page is not public.</p>
        <button type="button" onClick={onLeave} className="mt-4 rounded-full bg-leaf px-5 py-2 text-sm font-bold text-white">
          Back
        </button>
      </div>
    );
  }

  const pending = db.accounts.filter((item) => item.status === "pending").length;
  const review = db.accounts.filter((item) => item.status === "review").length;
  const approved = db.accounts.filter((item) => item.status === "accepted").length;
  const rejected = db.accounts.filter((item) => item.status === "rejected").length;
  const fees = db.accounts.filter((item) => item.feeConfirmed).length + db.licenses.filter((item) => item.feeConfirmed).length;
  const ecards = db.licenses.filter((item) => item.ecard).length;
  const permits = db.licenses.filter((item) => item.learnerPermit || item.kind.toUpperCase().includes("LEARN")).length;

  return (
    <section className="mx-auto max-w-lg space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-leaf">Admin panel</h1>
          <p className="text-xs font-semibold text-ink/60">{ADMIN_USER}</p>
          <p className="mt-1 text-xs font-semibold text-[#157a38]">{sharedNote}</p>
        </div>
        <button
          type="button"
          onClick={() => {
            logout();
            onLeave();
          }}
          className="rounded-full border border-line px-3 py-1 text-sm font-bold"
        >
          Log out
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {PANELS.map((item) => (
          <button key={item.id} type="button" onClick={() => setPanel(item.id)} className={`rounded-full px-3 py-1 text-xs font-bold ${panel === item.id ? "bg-[#157a38] text-white" : "bg-white"}`}>
            {item.label}
          </button>
        ))}
      </div>

      {panel === "requests" ? (
        <ul className="space-y-2">
          {(db.requests || []).length === 0 ? <p className="text-sm">No service requests yet.</p> : null}
          {(db.requests || []).map((item) => (
            <li key={item.id} className="rounded-2xl bg-white p-3 text-sm">
              <p className="font-bold">{item.name}</p>
              <p className="text-ink/60">{item.category} · {item.cnic} · {item.phone}</p>
              <p className="text-ink/60">{item.licenseNo ? `Licence ${item.licenseNo} · ` : ""}{item.vehicle} · {item.status} · {item.payment}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className="rounded-full bg-[#e0a020] px-3 py-1 text-xs font-bold" onClick={() => updateRequest(item.id, { status: "processing" })}>Start processing</button>
                <button type="button" className="rounded-full bg-leaf px-3 py-1 text-xs font-bold text-white" onClick={() => updateRequest(item.id, { status: "approved" })}>Approve</button>
                <button type="button" className="rounded-full bg-[#c51616] px-3 py-1 text-xs font-bold text-white" onClick={() => updateRequest(item.id, { status: "rejected" })}>Reject</button>
                <button type="button" className="rounded-full bg-[#163a86] px-3 py-1 text-xs font-bold text-white" onClick={() => updateRequest(item.id, { psid: item.psid || String(Date.now()).slice(0, 17), payment: "Unpaid" })}>{item.psid ? `PSID ${item.psid}` : "Issue PSID"}</button>
                <button type="button" className="rounded-full bg-pill px-3 py-1 text-xs font-bold" onClick={() => updateRequest(item.id, { payment: item.payment === "Paid" ? "Unpaid" : "Paid" })}>{item.payment === "Paid" ? "Mark unpaid" : "Mark paid"}</button>
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      {panel === "live" ? (
        <div className="grid grid-cols-2 gap-2">
          {[
            ["Service requests", (db.requests || []).length],
            ["Applications", db.accounts.length],
            ["Pending", pending],
            ["In review", review],
            ["Approved", approved],
            ["Rejected", rejected],
            ["Licenses", db.licenses.length],
            ["Fees confirmed", fees],
            ["E-cards", ecards],
            ["Learner permits", permits],
          ].map(([label, value]) => (
            <div key={String(label)} className="rounded-2xl bg-white p-3">
              <p className="text-[11px] font-bold tracking-wide text-ink/50 uppercase">{label}</p>
              <p className="text-2xl font-black text-leaf">{value}</p>
            </div>
          ))}
          <p className="col-span-2 text-xs font-semibold text-[#157a38]">Live — numbers change as soon as a record is saved on this device.</p>
        </div>
      ) : null}

      {panel === "status" ? (
        <ul className="space-y-2">
          {db.accounts.length === 0 ? <p className="text-sm">No applications yet.</p> : null}
          {db.accounts.map((account) => (
            <li key={account.id} className="rounded-2xl bg-white p-3 text-sm">
              <p className="font-bold">{account.name}</p>
              <p className="text-ink/60">{account.cnic} · {account.licenseType} · {account.status}{account.feeConfirmed ? " · fee confirmed" : ""}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className="rounded-full bg-[#e0a020] px-3 py-1 text-xs font-bold" onClick={() => setAccountStatus(account.id, "review")}>Review</button>
                <button type="button" className="rounded-full bg-leaf px-3 py-1 text-xs font-bold text-white" onClick={() => setAccountStatus(account.id, "accepted")}>Approve</button>
                <button type="button" className="rounded-full bg-[#c51616] px-3 py-1 text-xs font-bold text-white" onClick={() => setAccountStatus(account.id, "rejected")}>Reject</button>
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      {panel === "fee" ? (
        <ul className="space-y-2">
          {db.accounts.map((account) => (
            <li key={account.id} className="flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm">
              <span><b>{account.name}</b><span className="block text-ink/60">Application</span></span>
              <button type="button" className={`rounded-full px-3 py-1 text-xs font-bold ${account.feeConfirmed ? "bg-leaf text-white" : "bg-pill"}`} onClick={() => setAccountFee(account.id, !account.feeConfirmed)}>
                {account.feeConfirmed ? "Confirmed" : "Confirm fee"}
              </button>
            </li>
          ))}
          {db.licenses.map((record) => (
            <li key={record.id} className="flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm">
              <span><b>{record.name}</b><span className="block text-ink/60">{record.licenseNo}</span></span>
              <button type="button" className={`rounded-full px-3 py-1 text-xs font-bold ${record.feeConfirmed ? "bg-leaf text-white" : "bg-pill"}`} onClick={() => setLicenseFee(record.id, !record.feeConfirmed)}>
                {record.feeConfirmed ? "Confirmed" : "Confirm fee"}
              </button>
            </li>
          ))}
        </ul>
      ) : null}

      {panel === "ecard" ? <UploadList kind="ecard" records={db.licenses} /> : null}
      {panel === "learner" ? <UploadList kind="learner" records={db.licenses} /> : null}

      {panel === "regular" ? (
        <div>
          <button type="button" className="rounded-full bg-[#157a38] px-4 py-2 text-sm font-bold text-white" onClick={() => setEditing(blankLicense({ kind: "REGULAR" }))}>
            Add regular license
          </button>
        </div>
      ) : null}

      {panel === "edit" ? (
        <ul className="space-y-2">
          <li>
            <button type="button" className="text-sm font-bold text-leaf" onClick={() => setEditing(blankLicense())}>New record</button>
          </li>
          {db.licenses.map((record) => (
            <li key={record.id} className="flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm">
              <span><b>{record.name}</b><span className="block text-ink/60">{record.licenseNo} · {record.status}</span></span>
              <span className="flex gap-3">
                <button type="button" className="font-bold text-[#163a86]" onClick={() => setEditing(record)}>Edit</button>
                <button type="button" className="font-bold text-star" onClick={() => removeLicense(record.id)}>Delete</button>
              </span>
            </li>
          ))}
        </ul>
      ) : null}

      {editing && (panel === "regular" || panel === "edit") ? <LicenseEditor record={editing} onClose={() => setEditing(null)} /> : null}
    </section>
  );
}

function UploadList({ kind, records }: { kind: "ecard" | "learner"; records: LicenseRecord[] }) {
  return (
    <ul className="space-y-2">
      {records.length === 0 ? <p className="text-sm">Save a license first, then upload here.</p> : null}
      {records.map((record) => {
        const file = kind === "ecard" ? record.ecard : record.learnerPermit;
        return (
          <li key={record.id} className="rounded-2xl bg-white p-3 text-sm">
            <p className="font-bold">{record.name}</p>
            <p className="text-ink/60">{record.cnic} · {record.licenseNo}</p>
            {file ? (file.startsWith("data:application/pdf") ? <p className="mt-2 text-xs font-bold text-[#163a86]">PDF uploaded</p> : <img src={file} alt="" className="mt-2 max-h-40 rounded-lg" />) : null}
            <input
              type="file"
              accept={kind === "ecard" ? "image/*,application/pdf" : "image/*"}
              className={`${input} mt-2`}
              onChange={(event) => {
                const picked = event.target.files?.[0];
                if (!picked) return;
                const save = (url: string) => saveLicense(kind === "ecard" ? { ...record, ecard: url } : { ...record, learnerPermit: url, kind: record.kind || "LEARNER" });
                if (kind === "ecard") readUpload(picked, save);
                else readImage(picked, save);
              }}
            />
          </li>
        );
      })}
    </ul>
  );
}

function LicenseEditor({ record, onClose }: { record: LicenseRecord; onClose: () => void }) {
  const [draft, setDraft] = useState(record);

  function set<K extends keyof LicenseRecord>(key: K, value: LicenseRecord[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    saveLicense({ ...draft, cnic: draft.cnic.replace(/\D/g, "") });
    onClose();
  }

  const fields: { key: keyof LicenseRecord; label: string }[] = [
    { key: "name", label: "Name" },
    { key: "father", label: "Father / husband" },
    { key: "cnic", label: "CNIC" },
    { key: "dob", label: "Date of birth" },
    { key: "district", label: "District" },
    { key: "address", label: "Address" },
    { key: "phone", label: "Phone" },
    { key: "email", label: "Email" },
    { key: "licenseNo", label: "License number" },
    { key: "kind", label: "Type" },
    { key: "vehicles", label: "Allowed vehicles" },
    { key: "issueDate", label: "Issue date" },
    { key: "validFrom", label: "Valid from" },
    { key: "validTo", label: "Valid to" },
    { key: "status", label: "Status" },
    { key: "trackingNo", label: "Tracking number" },
    { key: "printedOn", label: "Printed on" },
    { key: "dispatchOn", label: "Dispatch on" },
    { key: "handler", label: "Delivery handler" },
  ];

  return (
    <form onSubmit={onSubmit} className="space-y-2 rounded-2xl bg-white p-3">
      <h3 className="font-black">Full license details</h3>
      {fields.map((field) => (
        <label key={field.key} className="block text-xs font-bold">
          {field.label}
          <input className={`${input} mt-1`} value={String(draft[field.key] ?? "")} onChange={(event) => set(field.key, event.target.value)} />
        </label>
      ))}
      <label className="block text-xs font-bold">
        Profile photo
        <input type="file" accept="image/*" className={`${input} mt-1`} onChange={(event) => {
          const file = event.target.files?.[0];
          if (!file) return;
          readImage(file, (url) => set("photo", url));
        }} />
      </label>
      <div className="flex gap-2 pt-2">
        <button type="submit" className="rounded-full bg-leaf px-4 py-2 text-sm font-bold text-white">Save</button>
        <button type="button" onClick={onClose} className="rounded-full bg-pill px-4 py-2 text-sm font-bold">Cancel</button>
      </div>
    </form>
  );
}
