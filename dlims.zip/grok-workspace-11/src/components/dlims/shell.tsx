import { useEffect, useState } from "react";
import { ELicense } from "@/components/dlims/elicense";
import { Track } from "@/components/dlims/track";
import { Verify } from "@/components/dlims/verify";
import { DuplicateForm } from "@/components/dlims/duplicate";
import { About, Downloads, FaqPage, Fees, Footer, Home, How } from "@/components/dlims/site-pages";
import { ApplyForm, Services, type ApplyKind } from "@/components/dlims/apply";
import { LoginForm, SignUpForm } from "@/components/dlims/auth";
import { AdminDesk } from "@/components/dlims/admin";
import { useSession } from "@/components/dlims/store";

export type TabId =
  | "home"
  | "about"
  | "how"
  | "faq"
  | "downloads"
  | "fees"
  | "elicense"
  | "track"
  | "verify"
  | "duplicate"
  | "login"
  | "signup"
  | "admin"
  | "services"
  | "apply"
  | "dastak"
  | "police";

const TEXT: { id: TabId; label: string }[] = [
  { id: "home", label: "Home" },
  { id: "about", label: "About us" },
  { id: "how", label: "How it works" },
  { id: "faq", label: "FAQ" },
  { id: "downloads", label: "Downloads" },
  { id: "fees", label: "Fee Structure" },
];

const PILLS: { id: TabId; label: string }[] = [
  { id: "elicense", label: "e-License" },
  { id: "track", label: "Track Application" },
  { id: "verify", label: "Verify License" },
];

export function DlimsApp() {
  const [tab, setTab] = useState<TabId>("home");
  const [menu, setMenu] = useState(false);
  const [applyKind, setApplyKind] = useState<ApplyKind>("learner");
  const session = useSession();

  useEffect(() => {
    document.body.style.overflow = menu ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menu]);

  function go(next: TabId | "apply-learner" | "apply-regular" | "apply-international") {
    if (next === "apply-learner" || next === "apply-regular" || next === "apply-international") {
      setApplyKind(next.slice(6) as ApplyKind);
      setTab("apply");
    } else setTab(next);
    setMenu(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const form = tab === "track" || tab === "elicense" || tab === "verify" || tab === "duplicate" || tab === "login" || tab === "signup" || tab === "admin" || tab === "apply" || tab === "services";
  const home = tab === "home";

  return (
    <div className={home ? "relative mx-auto min-h-dvh max-w-[480px] bg-[#f4f6f8] shadow-[0_0_40px_rgba(0,0,0,.08)]" : "relative min-h-dvh bg-[#f4f6f8]"}>
      {home ? null : (
      <div className="sticky top-0 z-30">
        <div className="brand-marquee banner-flow" aria-label="DLIMS, Dastak and Traffic Police Punjab">
          <div className="brand-track">
            <div className="brand-slide flex items-center justify-between gap-2 px-3 text-white">
              <p className="text-[11px] leading-tight font-bold sm:text-xs">
                All DLIMS
                <br />
                services are
                <br />
                Powered by
              </p>
              <p className="text-2xl leading-none font-black tracking-wide sm:text-4xl">
                <span className="mark-dlims">DLIMS</span> <span className="mark-ver">2.1</span>
              </p>
              <p className="text-right text-[11px] leading-tight font-black sm:text-sm">
                ONE WINDOW
                <br />
                FOR ALL
                <br />
                SERVICES
              </p>
            </div>
            <div className="brand-slide flex items-center justify-center">
              <img src="/dlims/dastak-cut.png" alt="Dastak" className="h-16 object-contain" />
            </div>
            <div className="brand-slide flex items-center justify-center gap-3 px-3 text-white">
              <img src="/dlims/tp-badge-cut.png" alt="" className="h-14 object-contain" />
              <p className="text-sm leading-tight font-black sm:text-lg">
                TRAFFIC POLICE
                <br />
                PUNJAB
              </p>
            </div>
          </div>
        </div>
        <div className="banner-edge" />
        <div className="border-b border-line/70 bg-[#f4f6f8]">
        <div className="mx-auto flex max-w-6xl items-center gap-2 px-3 py-2">
          <button type="button" onClick={() => go("home")} className="flex shrink-0 items-center gap-2">
            <img src="/dlims/dlims-online.jpg" alt="" className="h-12 w-12 object-contain" />
            <span>
              <span className="block text-lg leading-none font-black tracking-tight text-leaf">DLIMS</span>
              <span className="block max-w-28 text-[7px] leading-tight font-bold text-[#c4922a]">Driving License Information Management System</span>
            </span>
          </button>
          <span className="h-10 w-px shrink-0 bg-line" />
          <img src="/dlims/tp-badge-cut.png" alt="" className="h-12 shrink-0 object-contain" />
          <span className="text-[11px] leading-tight font-black tracking-wide text-leaf sm:text-sm">
            TRAFFIC POLICE
            <br />
            PUNJAB
          </span>
          <nav className="ml-auto hidden items-center gap-3 text-xs font-bold lg:flex">
            {TEXT.map((link) => (
              <button key={link.id} type="button" onClick={() => go(link.id)} className={tab === link.id ? "text-[#e0a020]" : "text-ink"}>
                {link.label}
              </button>
            ))}
            {PILLS.map((link) => (
              <button key={link.id} type="button" onClick={() => go(link.id)} className={`rounded-full px-3 py-1 ${tab === link.id ? "bg-[#f5a623] text-white" : "border border-line bg-white"}`}>
                {link.label}
              </button>
            ))}
            <button type="button" onClick={() => go("login")} className="rounded-full border border-line px-3 py-1">
              {session ? session.name : "Login"}
            </button>
            <button type="button" onClick={() => go("signup")} className="rounded-full bg-leaf px-3 py-1 text-white">
              Sign up
            </button>
          </nav>
          <button type="button" className="ml-auto grid size-11 place-items-center rounded-xl border border-ink/30 bg-[#f4f6f8] lg:hidden" aria-label="Open menu" onClick={() => setMenu(true)}>
            <span className="flex w-5 flex-col gap-[5px]" aria-hidden="true">
              <span className="h-[2px] bg-ink" />
              <span className="h-[2px] bg-ink" />
              <span className="h-[2px] bg-ink" />
            </span>
          </button>
        </div>
      </div>
      </div>
      )}

      <main className={home ? "" : `mx-auto max-w-6xl px-4 py-6 ${form ? "pb-16" : ""}`}>
        {tab === "home" ? <Home onOpen={(id) => go(id)} onMenu={() => setMenu(true)} /> : null}
        {tab === "services" ? <Services onApply={(kind) => go(`apply-${kind}`)} /> : null}
        {tab === "apply" ? <ApplyForm kind={applyKind} /> : null}
        {tab === "about" ? <About /> : null}
        {tab === "how" ? <How /> : null}
        {tab === "faq" ? <FaqPage /> : null}
        {tab === "downloads" ? <Downloads /> : null}
        {tab === "fees" ? <Fees onDuplicate={() => go("duplicate")} /> : null}
        {tab === "elicense" ? <ELicense /> : null}
        {tab === "track" ? (
          <div className="mx-auto max-w-md">
            <Track />
          </div>
        ) : null}
        {tab === "verify" ? (
          <div className="mx-auto max-w-md">
            <Verify />
          </div>
        ) : null}
        {tab === "duplicate" ? <DuplicateForm onBack={() => go("fees")} /> : null}
        {tab === "login" ? <LoginForm onAdmin={() => go("admin")} /> : null}
        {tab === "signup" ? <SignUpForm /> : null}
        {tab === "admin" ? <AdminDesk onLeave={() => go("home")} /> : null}
      </main>

      {form || home ? null : <Footer />}

      {menu ? (
        <div className="fixed inset-0 z-40">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-ink/40" onClick={() => setMenu(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-64 flex-col bg-[#f7f8fa] px-5 py-8">
            {TEXT.map((link) => (
              <button key={link.id} type="button" onClick={() => go(link.id)} className="min-h-11 text-left text-base font-medium">
                {link.label}
              </button>
            ))}
            <div className="mt-4 flex flex-wrap gap-2">
              <button type="button" onClick={() => go("elicense")} className="rounded-full bg-pill px-4 py-2 text-sm font-semibold">
                e-License
              </button>
              <button type="button" onClick={() => go("track")} className="rounded-full bg-pill px-4 py-2 text-sm font-semibold">
                Track Application
              </button>
            </div>
            <button type="button" onClick={() => go("verify")} className="mt-3 w-fit rounded-full bg-[#f5c400] px-5 py-2 text-sm font-bold text-white">
              Verify License
            </button>
            <div className="mt-6 space-y-2 border-t border-line pt-4">
              <button type="button" onClick={() => go("login")} className="block min-h-11 text-left text-base font-bold">
                {session ? session.name : "Login"}
              </button>
              <button type="button" onClick={() => go("signup")} className="block min-h-11 text-left text-base font-bold">
                Sign up
              </button>
            </div>
          </aside>
        </div>
      ) : null}
    </div>
  );
}
