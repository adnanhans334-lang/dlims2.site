import { useState, type FormEvent } from "react";
import { saveRequest } from "@/components/dlims/store";

export type ApplyKind = "learner" | "regular" | "international";

const TITLES: Record<ApplyKind, { title: string; hint: string }> = {
  learner: { title: "Learner License", hint: "New learner driving licence application." },
  regular: { title: "Regular License Renewal", hint: "Renew an existing regular driving licence." },
  international: { title: "International License", hint: "Apply for an international driving licence." },
};

export function Services({ onApply }: { onApply: (kind: ApplyKind) => void }) {
  const items: { kind: ApplyKind; label: string }[] = [
    { kind: "learner", label: "LEARNER LICENSE" },
    { kind: "regular", label: "REGULAR LICENSE" },
    { kind: "international", label: "INTERNATIONAL LICENSE" },
  ];
  return (
    <div className="mx-auto max-w-lg">
      <button type="button" className="flex w-full items-center justify-between rounded-[28px] bg-[#e2b423] px-6 py-5 text-left text-2xl font-black text-[#1a1a1a]">
        Apply Service
        <span className="grid size-14 place-items-center rounded-2xl bg-[#f3d56a] text-3xl">↗</span>
      </button>
      <div className="mt-8 grid gap-4">
        {items.map((item) => (
          <button key={item.kind} type="button" onClick={() => onApply(item.kind)} className="flex items-center gap-3">
            <span className="grid size-8 place-items-center rounded-full bg-[#1f9e4a] text-sm font-black text-white">✓</span>
            <span className="flex-1 rounded-full border border-[#e6e6e6] bg-white px-5 py-3 text-center text-sm font-black tracking-wide text-[#157a38] shadow-sm">
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function ApplyForm({ kind }: { kind: ApplyKind }) {
  const copy = TITLES[kind];
  const [message, setMessage] = useState("");
  const [ref, setRef] = useState("");

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const name = String(data.get("name") || "").trim();
    const father = String(data.get("father") || "").trim();
    const cnic = String(data.get("cnic") || "").replace(/\D/g, "");
    const dob = String(data.get("dob") || "").trim();
    const phone = String(data.get("phone") || "").trim();
    const address = String(data.get("address") || "").trim();
    if (!name || !father || cnic.length < 11 || !dob || !phone || !address) {
      setMessage("Name, father name, CNIC, date of birth, phone and address are required.");
      setRef("");
      return;
    }
    try {
      const id = await saveRequest({
        category: kind,
        name: name.toUpperCase(),
        father: father.toUpperCase(),
        cnic,
        dob,
        phone,
        email: String(data.get("email") || "").trim(),
        district: String(data.get("district") || "FAISALABAD").trim().toUpperCase(),
        address: address.toUpperCase(),
        licenseNo: String(data.get("licenseNo") || "").trim().toUpperCase(),
        vehicle: String(data.get("vehicle") || "").trim(),
      });
      setMessage("");
      setRef(id.slice(0, 8).toUpperCase());
      form.reset();
    } catch (error) {
      setRef("");
      setMessage(error instanceof Error ? error.message : "Could not send the request. Try again.");
    }
  }

  return (
    <form onSubmit={onSubmit} className="mx-auto max-w-lg space-y-3 rounded-3xl bg-white p-5">
      <p className="text-xs font-black tracking-[0.2em] text-[#b8962e]">APPLICATION</p>
      <h1 className="text-2xl font-black text-leaf">{copy.title}</h1>
      <p className="text-sm text-ink/70">{copy.hint} After submit, the request goes to the admin panel.</p>
      <Field name="name" label="Full name" />
      <Field name="father" label="Father / husband name" />
      <Field name="cnic" label="CNIC" inputMode="numeric" />
      <Field name="dob" label="Date of birth" placeholder="YYYY-MM-DD" />
      <Field name="phone" label="Phone" inputMode="tel" />
      <Field name="email" label="Email" type="email" required={false} />
      <Field name="district" label="District" defaultValue="FAISALABAD" />
      <Field name="address" label="Address" />
      {kind === "learner" ? (
        <label className="block text-sm font-semibold">
          Vehicle
          <select name="vehicle" className="mt-1 w-full rounded-xl border border-line px-3 py-2">
            <option>M/Cycle</option>
            <option>Car</option>
            <option>M/Cycle + Car</option>
          </select>
        </label>
      ) : (
        <Field name="licenseNo" label={kind === "regular" ? "Current licence number" : "Regular licence number"} />
      )}
      <button type="submit" className="w-full rounded-full bg-[#157a38] py-3 font-bold text-white">
        Submit request
      </button>
      {message ? <p className="rounded-xl bg-[#fff4f4] px-3 py-2 text-sm text-[#9b1c1c]">{message}</p> : null}
      {ref ? <p className="rounded-xl bg-[#eef8f1] px-3 py-2 text-sm font-semibold text-[#157a38]">Request sent to admin. Reference {ref}.</p> : null}
    </form>
  );
}

function Field({
  name,
  label,
  type = "text",
  required = true,
  placeholder,
  defaultValue,
  inputMode,
}: {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
  defaultValue?: string;
  inputMode?: "numeric" | "tel" | "email";
}) {
  return (
    <label className="block text-sm font-semibold">
      {label}
      {required ? <span className="text-[#d10000]"> *</span> : null}
      <input name={name} type={type} required={required} placeholder={placeholder} defaultValue={defaultValue} inputMode={inputMode} className="mt-1 w-full rounded-xl border border-line px-3 py-2 font-normal" />
    </label>
  );
}
