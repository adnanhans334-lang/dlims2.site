import { o as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Bus, i as Car, o as Bike, r as Tractor, s as Accessibility, t as Truck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-II_kDEcG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useCaptcha() {
	const answer = (0, import_react.useRef)(2);
	const [question, setQuestion] = (0, import_react.useState)("1 + 1");
	const refresh = (0, import_react.useCallback)(() => {
		const left = 1 + Math.floor(Math.random() * 8);
		const right = 1 + Math.floor(Math.random() * 8);
		answer.current = left + right;
		setQuestion(`${left} + ${right}`);
	}, []);
	(0, import_react.useEffect)(() => {
		refresh();
	}, [refresh]);
	return {
		question,
		refresh,
		check: (0, import_react.useCallback)((value) => {
			if (!value.trim()) return false;
			return Number(value) === answer.current;
		}, [])
	};
}
function Heading({ title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-[1.7rem] leading-none font-black tracking-tight text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-2 h-[3px] w-11 rounded-full bg-gold" })]
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-[1.05rem] leading-tight font-bold text-ink",
		children
	});
}
function Star() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-star",
		children: " *"
	});
}
function TextBox(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: "w-full rounded-md border border-line bg-white px-3 py-3 text-base text-ink outline-none placeholder:text-muted"
	});
}
function Go({ children, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "submit",
		className: `w-full rounded-full py-3.5 text-lg font-bold text-white ${tone === "gold" ? "bg-mustard" : "bg-gold"}`,
		children
	});
}
function Art({ src, caption }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 rounded-[1.25rem] bg-ill px-2 pt-3 pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "mx-auto w-full"
		}), caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-center text-[1.7rem] leading-none font-black text-ink",
			children: caption
		}) : null]
	});
}
function Note({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "rounded-lg bg-pill px-3 py-3 text-sm font-semibold text-ink",
		children
	});
}
function Choice({ name, label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-12 items-center gap-2 rounded-lg bg-pill px-3 py-2 text-[15px] leading-tight font-semibold text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "radio",
				name,
				checked,
				onChange,
				className: "sr-only"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `grid size-5 shrink-0 place-items-center rounded-full border-2 bg-white ${checked ? "border-radio" : "border-[#c5cad1]"}`,
				children: checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-radio" }) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })
		]
	});
}
function Qr({ value, caption }) {
	const [src, setSrc] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let alive = true;
		import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((mod) => mod.toDataURL(value, {
			margin: 1,
			width: 220,
			errorCorrectionLevel: "M"
		}).then((url) => {
			if (alive) setSrc(url);
		}));
		return () => {
			alive = false;
		};
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "aspect-square w-full overflow-hidden rounded-lg border border-line bg-card p-1",
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: caption,
			className: "size-full object-contain"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-full animate-pulse bg-paper" })
	});
}
function CatIcon$1({ kind }) {
	const common = "h-7 w-10";
	if (kind === "bike") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 36",
		className: common,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "14",
				cy: "24",
				r: "8",
				fill: "none",
				stroke: "#1d4e9f",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "50",
				cy: "24",
				r: "8",
				fill: "none",
				stroke: "#1d4e9f",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M14 24h10l6-10h12l6 10M28 14l6 10M36 8h8",
				fill: "none",
				stroke: "#1d4e9f",
				strokeWidth: "3",
				strokeLinejoin: "round"
			})
		]
	});
	if (kind === "car" || kind === "psv") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 32",
		className: common,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 20h48l-4-8H22L14 20H8v6h6a5 5 0 0 0 10 0h16a5 5 0 0 0 10 0h6v-6",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "24",
				r: "3",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "46",
				cy: "24",
				r: "3",
				fill: "#fff"
			})
		]
	});
	if (kind === "ltv") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 36",
		className: common,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 22V12h16l8 8h20v8H10z",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "28",
				r: "5",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "48",
				cy: "28",
				r: "5",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "28",
				r: "2",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "48",
				cy: "28",
				r: "2",
				fill: "#fff"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 32",
		className: common,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "10",
				width: "40",
				height: "14",
				rx: "2",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18",
				cy: "26",
				r: "3",
				fill: "#1d4e9f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "42",
				cy: "26",
				r: "3",
				fill: "#1d4e9f"
			})
		]
	});
}
function LicenseCard({ photo, licenseNo, name, father, dob, cnic, issueDate, validTo, address, vehicles }) {
	const allowed = (vehicles || "").toUpperCase();
	const on = (label) => allowed.includes(label);
	const cats = [
		{
			name: "BIKE",
			icon: "bike",
			on: on("BIKE") || on("M/CYCLE") || on("MOTORCYCLE")
		},
		{
			name: "CAR",
			icon: "car",
			on: on("CAR")
		},
		{
			name: "LTV",
			icon: "ltv",
			on: on("LTV")
		},
		{
			name: "HTV",
			icon: "htv",
			on: on("HTV")
		},
		{
			name: "PSV",
			icon: "psv",
			on: on("PSV")
		},
		{
			name: "TRACTOR",
			icon: "tractor",
			on: on("TRACTOR")
		},
		{
			name: "RIKSHAW",
			icon: "rik",
			on: on("RIKSHAW") || on("RICKSHAW")
		},
		{
			name: "HEAVY MACHINERY",
			icon: "heavy",
			on: on("HEAVY")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "relative mx-auto w-full max-w-sm overflow-hidden rounded-[28px] border border-[#e6eef8] bg-white shadow-[0_16px_40px_rgba(20,40,80,.12)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 opacity-70",
				style: { backgroundImage: "radial-gradient(circle at 18% 12%, transparent 0 40px, rgba(180,205,230,.35) 41px), repeating-linear-gradient(115deg, transparent 0 14px, rgba(190,210,230,.35) 15px 16px)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative px-4 pt-4 pb-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/emblem-cut.png",
								alt: "",
								className: "size-14 object-contain"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-1 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-black tracking-wide text-[#1a3f8b]",
									children: "E-DRIVING LICENSE"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold tracking-wide text-[#1a3f8b]",
									children: "TRAFFIC POLICE PUNJAB"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/tp-badge-cut.png",
								alt: "",
								className: "size-14 object-contain"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-3 grid size-36 place-items-center overflow-hidden rounded-full border-4 border-[#7eb0d4] bg-[#d9dde3]",
						children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: photo,
							alt: "",
							className: "size-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 64 64",
							className: "size-24 text-[#9aa0a8]",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "32",
								cy: "22",
								r: "10",
								fill: "currentColor"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M12 56c2-14 10-20 20-20s18 6 20 20",
								fill: "currentColor"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xl font-black tracking-wide text-[#1a3f8b]",
						children: licenseNo || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-2xl font-black uppercase leading-tight text-ink",
						children: name || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm font-black uppercase",
						children: ["So/Do/Wo : ", father || "—"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 text-[#1a3f8b]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-bold tracking-wide",
								children: "DATE OF BIRTH"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-black text-ink",
								children: prettyDate(dob)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-bold tracking-wide",
								children: "CNIC"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-black text-ink",
								children: prettyCnic(cnic)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-bold tracking-wide",
								children: "ISSUE DATE"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-black text-ink",
								children: prettyDate(issueDate)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-bold tracking-wide",
								children: "VALID TILL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-black text-ink",
								children: prettyDate(validTo)
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-[#1a3f8b]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[10px] font-bold tracking-wide",
							children: "ADDRESS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base font-black uppercase text-ink",
							children: address || "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid grid-cols-4 border border-[#d7e0ea] bg-white/80 text-center text-[10px] font-bold text-ink",
						children: cats.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative border border-[#e6eef5] px-1 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `mx-auto grid h-8 place-items-center ${cat.on ? "" : "opacity-40"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatIcon$1, { kind: cat.icon })
								}),
								!cat.on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-2 right-2 left-2 text-xl leading-none text-[#1a3f8b]",
									children: "✕"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-tight",
									children: cat.name
								})
							]
						}, cat.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-end justify-between gap-3 pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-24",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qr, {
								value: licenseNo || cnic || "DLIMS",
								caption: "License QR"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right text-[#1a3f8b]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-serif text-3xl italic leading-none",
									children: "Signature"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold",
									children: "Licensing Authority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold",
									children: "Punjab"
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative bg-[#163a86] py-2.5 text-center text-sm font-bold text-white",
				children: "This is a valid Electronic Driving License"
			})
		]
	});
}
function prettyDate(value) {
	if (!value) return "—";
	const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
	return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
}
function prettyCnic(value) {
	const digits = (value || "").replace(/\D/g, "");
	if (digits.length !== 13) return value || "—";
	return `${digits.slice(0, 5)}-${digits.slice(5, 12)}-${digits.slice(12)}`;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var lookupLicense = createServerFn({ method: "POST" }).validator((input) => ({
	cnic: String(input?.cnic ?? "").replace(/\D/g, ""),
	dob: String(input?.dob ?? "").trim(),
	licenseNo: String(input?.licenseNo ?? "").replace(/\s/g, "").toLowerCase()
})).handler(createSsrRpc("68e54590d80575eb23fbef189c5868d6a4c0b0bb5115b6a89f2143b1863918a7"));
var listSharedLicenses = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("787e4c45bd26ea737b1f795e45d5061c88de68c29ae2ba471160e0178b16898e"));
var saveSharedLicense = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("e4cced8738d1180f6a77949e6513d1a9fc8bbdaceed4c3fcc4c56386656e0b2c"));
var removeSharedLicense = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("3cf8ec612c2fa355f8ee6c7fa62ee7d620dbde8672ed6649686e06b5425f4f64"));
var KINDS$1 = [
	"Regular License",
	"International License",
	"Juvenile License"
];
function ELicense() {
	const captcha = useCaptcha();
	const [kind, setKind] = (0, import_react.useState)("Regular License");
	const [cnic, setCnic] = (0, import_react.useState)("");
	const [dob, setDob] = (0, import_react.useState)("");
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [record, setRecord] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		if (!cnic.trim() || !dob.trim()) {
			setMessage("CNIC/Passport and date of birth are required.");
			setRecord(null);
			return;
		}
		if (!/^\d{4}-\d{2}-\d{2}$/.test(dob.trim())) {
			setMessage("Enter date of birth as YYYY-MM-DD.");
			setRecord(null);
			return;
		}
		if (!captcha.check(answer)) {
			setMessage("Captcha is incorrect.");
			setRecord(null);
			captcha.refresh();
			setAnswer("");
			return;
		}
		setBusy(true);
		try {
			const found = await lookupLicense({ data: {
				cnic: cnic.replace(/\D/g, ""),
				dob: dob.trim()
			} });
			setRecord(found);
			setMessage(found ? "" : "No record found.");
		} catch {
			setRecord(null);
			setMessage("Could not reach the shared database.");
		} finally {
			setBusy(false);
			captcha.refresh();
			setAnswer("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl items-start gap-8 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "e-Licence" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3",
						children: KINDS$1.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: item === "Juvenile License" ? "col-span-2" : "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								name: "elicense-kind",
								label: item,
								checked: kind === item,
								onChange: () => setKind(item)
							})
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["Enter CNIC/Passport", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: cnic,
						onChange: (event) => setCnic(event.target.value),
						autoComplete: "off",
						placeholder: "CNIC/Passport without dashes",
						"aria-label": "CNIC or passport"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["Date of Birth", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: dob,
						onChange: (event) => setDob(event.target.value),
						inputMode: "numeric",
						placeholder: "YYYY-MM-DD",
						"aria-label": "Date of birth"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: [
						"What is ",
						captcha.question,
						" ="
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: answer,
						onChange: (event) => setAnswer(event.target.value),
						inputMode: "numeric",
						placeholder: "Enter Here...",
						"aria-label": "Captcha answer"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
						tone: "gold",
						children: busy ? "Checking..." : "Generate e-Licence"
					})
				]
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: message })
			}) : null,
			record ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadedCard, { record })
			}) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden lg:block",
			children: record ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadedCard, { record }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Art, { src: "/dlims/verify-art.jpg" })
		})]
	});
}
function isPdf(src) {
	return src.startsWith("data:application/pdf") || src.toLowerCase().includes(".pdf");
}
function UploadedCard({ record }) {
	const uploadedPdf = record.ecard && isPdf(record.ecard) ? record.ecard : "";
	const picture = record.ecard && !uploadedPdf ? record.ecard : "";
	if (picture) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: picture,
		alt: "E-card",
		className: "w-full rounded-2xl bg-white shadow-lg"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => downloadImagePdf(picture),
		className: "mt-4 w-full rounded-full bg-[#163a86] py-3 text-sm font-bold text-white",
		children: "Download PDF"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [uploadedPdf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		title: "Uploaded e-card",
		src: uploadedPdf,
		className: "h-[560px] w-full rounded-2xl bg-white"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseCard, {
		photo: record.photo,
		licenseNo: record.licenseNo,
		name: record.name,
		father: record.father,
		dob: record.dob,
		cnic: record.cnic,
		issueDate: record.issueDate,
		validTo: record.validTo,
		address: record.address,
		vehicles: record.vehicles
	}), uploadedPdf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: uploadedPdf,
		download: "DLIMS-e-license.pdf",
		className: "mt-4 block rounded-full bg-[#163a86] py-3 text-center text-sm font-bold text-white",
		children: "Download PDF"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => downloadCardPdf(record),
		className: "mt-4 w-full rounded-full bg-[#163a86] py-3 text-sm font-bold text-white",
		children: "Download PDF"
	})] });
}
function downloadImagePdf(src) {
	const image = new Image();
	image.onload = () => {
		const canvas = document.createElement("canvas");
		const scale = Math.min(1, 1200 / Math.max(image.width, image.height));
		const w = Math.max(1, Math.round(image.width * scale));
		const h = Math.max(1, Math.round(image.height * scale));
		canvas.width = w;
		canvas.height = h;
		canvas.getContext("2d")?.drawImage(image, 0, 0, w, h);
		const raw = atob(canvas.toDataURL("image/jpeg", .9).split(",")[1] || "");
		const jpg = new Uint8Array(raw.length);
		for (let i = 0; i < raw.length; i += 1) jpg[i] = raw.charCodeAt(i);
		const enc = new TextEncoder();
		const chunks = [];
		let length = 0;
		const push = (bytes) => {
			chunks.push(bytes);
			length += bytes.length;
		};
		const pushStr = (value) => push(enc.encode(value));
		const offsets = [
			0,
			0,
			0,
			0,
			0,
			0
		];
		const obj = (n, value) => {
			offsets[n] = length;
			pushStr(value);
		};
		pushStr("%PDF-1.4\n");
		obj(1, "1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj\n");
		obj(2, "2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj\n");
		obj(3, `3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /Contents 4 0 R /Resources<< /XObject<< /Im0 5 0 R >> >> >>endobj\n`);
		const content = enc.encode(`q\n${w} 0 0 ${h} 0 0 cm\n/Im0 Do\nQ\n`);
		offsets[4] = length;
		pushStr(`4 0 obj<< /Length ${content.length} >>stream\n`);
		push(content);
		pushStr("endstream endobj\n");
		offsets[5] = length;
		pushStr(`5 0 obj<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>stream\n`);
		push(jpg);
		pushStr("\nendstream endobj\n");
		const xref = length;
		pushStr("xref\n0 6\n0000000000 65535 f \n");
		for (let i = 1; i <= 5; i += 1) pushStr(`${String(offsets[i]).padStart(10, "0")} 00000 n \n`);
		pushStr(`trailer<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
		const size = chunks.reduce((sum, part) => sum + part.length, 0);
		const pdf = new Uint8Array(size);
		let offset = 0;
		chunks.forEach((part) => {
			pdf.set(part, offset);
			offset += part.length;
		});
		const link = document.createElement("a");
		link.href = URL.createObjectURL(new Blob([pdf], { type: "application/pdf" }));
		link.download = "DLIMS-e-license.pdf";
		link.click();
	};
	image.src = src;
}
function downloadCardPdf(record) {
	const lines = [
		"E-DRIVING LICENSE",
		"TRAFFIC POLICE PUNJAB",
		"License " + record.licenseNo,
		record.name,
		"So/Do/Wo " + record.father,
		"DOB " + record.dob,
		"CNIC " + record.cnic,
		"Issue " + record.issueDate,
		"Valid " + record.validTo,
		record.address
	];
	const safe = (value) => value.replace(/[()\\]/g, " ").slice(0, 80);
	const stream = `BT /F1 14 Tf 40 780 Td 20 TL ${lines.map((line) => `(${safe(line)}) Tj T*`).join(" ")} ET`;
	const objects = [
		"1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj",
		"2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj",
		"3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources<< /Font<< /F1 5 0 R >> >> >>endobj",
		`4 0 obj<< /Length ${stream.length} >>stream\n${stream}\nendstream endobj`,
		"5 0 obj<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>endobj"
	];
	let body = "%PDF-1.4\n";
	const offsets = [0];
	objects.forEach((obj) => {
		offsets.push(body.length);
		body += obj + "\n";
	});
	const xref = body.length;
	body += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
	for (let i = 1; i < offsets.length; i += 1) body += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
	body += `trailer<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
	const link = document.createElement("a");
	link.href = URL.createObjectURL(new Blob([body], { type: "application/pdf" }));
	link.download = "DLIMS-e-license.pdf";
	link.click();
}
function Track() {
	const captcha = useCaptcha();
	const [cnic, setCnic] = (0, import_react.useState)("");
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [record, setRecord] = (0, import_react.useState)(null);
	async function onSubmit(event) {
		event.preventDefault();
		const id = cnic.replace(/\D/g, "");
		if (!id) {
			setMessage("Enter CNIC/Passport.");
			setRecord(null);
			return;
		}
		if (!captcha.check(answer)) {
			setMessage("Captcha is incorrect.");
			setRecord(null);
			captcha.refresh();
			setAnswer("");
			return;
		}
		try {
			const found = await lookupLicense({ data: { cnic: id } });
			setRecord(found);
			setMessage(found ? "" : "No record found.");
		} catch {
			setRecord(null);
			setMessage("Could not reach the shared database.");
		}
		captcha.refresh();
		setAnswer("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "Track License" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["Enter CNIC/PASSPORT", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
					value: cnic,
					onChange: (event) => setCnic(event.target.value),
					autoComplete: "off",
					placeholder: "CNIC/Passport without dashes",
					"aria-label": "CNIC or passport"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: [
					"What is ",
					captcha.question,
					" ="
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
					value: answer,
					onChange: (event) => setAnswer(event.target.value),
					inputMode: "numeric",
					placeholder: "Enter Here...",
					"aria-label": "Captcha answer"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
					tone: "amber",
					children: "Track License"
				})
			]
		}),
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: message })
		}) : null,
		record ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-[1.6rem] bg-ill px-4 pt-6 pb-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/dlims/track-art.jpg",
					alt: "",
					className: "mx-auto w-full max-w-sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[1.7rem] leading-none font-black",
					children: "Tracking Result"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-4 max-w-sm text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-lg text-ink/40",
						children: ["Delivery Handler ", record.handler || "Pakistan Post"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 space-y-4 text-base",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Printed On:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium",
									children: record.printedOn || "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Dispatch On :" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium",
									children: record.dispatchOn || "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Tracking No." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium",
									children: record.trackingNo || "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-medium",
									children: record.status
								})]
							})
						]
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/dlims/track-art.jpg",
			alt: "",
			className: "mx-auto mt-8 w-full max-w-sm"
		})
	] });
}
var KINDS = [
	"Regular License",
	"International License",
	"Juvenile License"
];
function Verify() {
	const captcha = useCaptcha();
	const [kind, setKind] = (0, import_react.useState)("Regular License");
	const [cnic, setCnic] = (0, import_react.useState)("");
	const [licenseNo, setLicenseNo] = (0, import_react.useState)("");
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [record, setRecord] = (0, import_react.useState)(null);
	async function onSubmit(event) {
		event.preventDefault();
		const id = cnic.replace(/\D/g, "");
		const number = licenseNo.replace(/\s/g, "");
		if (!id) {
			setMessage("Enter CNIC/Passport.");
			setRecord(null);
			return;
		}
		if (!number) {
			setMessage("License number is required.");
			setRecord(null);
			return;
		}
		if (!captcha.check(answer)) {
			setMessage("Captcha is incorrect.");
			setRecord(null);
			captcha.refresh();
			setAnswer("");
			return;
		}
		try {
			const found = await lookupLicense({ data: {
				cnic: id,
				licenseNo: number
			} });
			setRecord(found);
			setMessage(found ? "" : "No license record found.");
		} catch {
			setRecord(null);
			setMessage("Could not reach the shared database.");
		}
		captcha.refresh();
		setAnswer("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "Verify License" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: item === "Juvenile License" ? "col-span-2" : "",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
							name: "verify-kind",
							label: item,
							checked: kind === item,
							onChange: () => setKind(item)
						})
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["Enter CNIC/Passport", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
					value: cnic,
					onChange: (event) => setCnic(event.target.value),
					autoComplete: "off",
					placeholder: "CNIC/Passport without dashes",
					"aria-label": "CNIC or passport"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: ["License Number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
					value: licenseNo,
					onChange: (event) => setLicenseNo(event.target.value),
					autoComplete: "off",
					placeholder: "Enter license number",
					"aria-label": "License number"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldLabel, { children: [
					"What is ",
					captcha.question,
					" ="
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
					value: answer,
					onChange: (event) => setAnswer(event.target.value),
					inputMode: "numeric",
					placeholder: "Enter Here...",
					"aria-label": "Captcha answer"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
					tone: "amber",
					children: "Verify License"
				})
			]
		}),
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: message })
		}) : null,
		record ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mt-6 rounded-3xl bg-[#f4f7fb] px-5 py-6",
			children: [
				record.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: record.photo,
					alt: "",
					className: "mx-auto size-36 rounded-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid size-36 place-items-center rounded-full bg-[#d9dde3] text-sm font-bold text-ink/50",
					children: "Photo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-2xl font-black",
					children: "User Information"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "CNIC/:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.cnic })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Name:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.name })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-ink/50",
								children: "Father/Husband Name:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.father })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "District:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.district })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-6 text-2xl font-black",
					children: "License Information"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-ink/50",
								children: "License Number:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.licenseNo })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Issue Date:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.issueDate })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Valid From:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.validFrom })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Valid To:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.validTo })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Allowed Vehicles:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.vehicles })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-ink/50",
							children: "Status:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.status })] })
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Art, { src: "/dlims/verify-art.jpg" })
	] });
}
var FIELDS = [
	[
		"name",
		"Name*",
		"ZAIGHUM MAZHAR"
	],
	[
		"father",
		"Father/Husband Name*",
		"MAZHAR SULTAN"
	],
	[
		"dob",
		"Date of Birth*",
		"1989-08-06"
	],
	[
		"phone",
		"Phone Number*",
		"0345-9137378"
	],
	[
		"emergency",
		"Emergency Contact Number*",
		"03459137378"
	],
	[
		"email",
		"Email*",
		"hansraja4@gmail.com"
	],
	[
		"address",
		"Address*",
		"SATYAN ROAD P-32 ST 1 RACHNA TOWN FSD"
	]
];
function DuplicateForm({ onBack }) {
	const [done, setDone] = (0, import_react.useState)(false);
	const [files, setFiles] = (0, import_react.useState)({});
	function onSubmit(event) {
		event.preventDefault();
		if (!event.currentTarget.querySelector("input[name=\"certify\"]")?.checked) return;
		setDone(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md overflow-hidden rounded-3xl bg-white shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 bg-leaf px-3 py-3 text-white",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "grid size-9 place-items-center text-xl",
				"aria-label": "Back",
				children: "←"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold",
				children: "Duplicate Driving License"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-3 px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-ink/70",
					children: "Step 2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 overflow-hidden rounded-full bg-[#e6e6e6]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-2/3 rounded-full bg-[#3dbe63]" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-black text-[#1a3f8b]",
					children: "Personal Details"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "-mt-2 text-sm text-ink/60",
					children: "Enter personal details of the applicant"
				}),
				FIELDS.map(([name, label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name,
						defaultValue: value,
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold"
					})]
				}, name)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: "Nationality*"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						defaultValue: "Pakistani",
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Pakistani" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: "Height*"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						defaultValue: "5.7",
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "5.7" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "5.6" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "5.8" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: "Citizen Type*"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						defaultValue: "CIVILIAN",
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "CIVILIAN" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: "Blood Group*"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						defaultValue: "O+",
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "O+" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "A+" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "B+" })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-2 text-base font-black",
					children: "Current Address"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mb-1 block text-xs text-ink/50",
						children: "District*"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						defaultValue: "FAISALABAD",
						className: "w-full rounded-lg border border-line px-3 py-3 text-sm font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "FAISALABAD" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "LAHORE" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-2 text-base font-black",
					children: "License Allowed Vehicle(s) Type"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						defaultChecked: true,
						className: "size-4 accent-leaf"
					}), " M/CYCLE"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						defaultChecked: true,
						className: "size-4 accent-leaf"
					}), " LTV"]
				}),
				[
					[
						"photo",
						"Upload Photo*",
						"Upload your photo and size should be only 500kb max."
					],
					[
						"cnicf",
						"Upload CNIC Front*",
						"Upload front CNIC and size should be only 500kb max."
					],
					[
						"cnicb",
						"Upload CNIC Back*",
						"Upload back CNIC and size should be only 500kb max."
					],
					[
						"fir",
						"Upload Lost Complaint / FIR*",
						"Upload Lost Complaint / FIR and size should be only 500kb max."
					],
					[
						"med",
						"Upload Medical Certificate*",
						"Upload medical certificate and size should be only 500kb max."
					]
				].map(([key, title, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-black",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-pink-50 px-2 py-1 text-xs text-pink-500",
							children: "View Guidelines"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid h-36 cursor-pointer place-items-center rounded-xl border border-dashed border-line text-center text-ink/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "sr-only",
							onChange: (event) => {
								const file = event.target.files?.[0];
								setFiles((prev) => ({
									...prev,
									[key]: file ? file.name : ""
								}));
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-3xl",
							children: "🖼️"
						}), files[key] || "Upload here"] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-[#e0a020]",
						children: ["ⓘ ", hint]
					})
				] }, key)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "certify",
						type: "checkbox",
						required: true,
						className: "mt-1 size-4 accent-leaf"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I hereby certify that the information provided by me is correct and I will be liable for legal action, if found false or forged." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "w-full rounded-full bg-leaf py-3 font-bold text-white",
					children: "Next"
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-leaf-soft px-3 py-2 text-sm font-semibold text-leaf",
					children: "Details are filled on this screen only. Nothing is sent."
				}) : null
			]
		})]
	});
}
var FAQ = [
	{
		q: "What documents are required for the online application process?",
		a: [
			"Picture (Face)",
			"Scanned copy/picture of Original CNIC's front",
			"Scanned copy/picture of Original CNIC's back",
			"Medical Certificate signed by a government doctor in case age is above 50 years"
		]
	},
	{
		q: "How can I apply for an online learner driving license?",
		a: ["Create an account, fill the learner application, generate a PSID, pay, then print the learner license from the system."]
	},
	{
		q: "What are the fees associated with applying for an online learner driving license?",
		a: ["Fees depend on the vehicle category. Open Fee Structure for the regular, renewal, duplicate, and international tables."]
	},
	{
		q: "How long does it take to receive the online learner driving license after applying?",
		a: ["After payment confirmation the application is reviewed. You are notified when it is approved."]
	},
	{
		q: "How will I get/download my learner driving license after filling the form and making payment?",
		a: ["Once approved, print the learner license directly from the system."]
	},
	{
		q: "Are there any specific guidelines for uploading documents in the online application?",
		a: ["Upload a face picture, both sides of the original CNIC, and a medical certificate when the applicant is over 50."]
	}
];
var STEPS = {
	learner: [
		[
			"STEP 1",
			"Create Account & Login",
			"Begin your driving journey: sign up or log in to access our online platform. Streamlined processes await, so start today for a smoother path to driving."
		],
		[
			"STEP 2",
			"Fill Application Form",
			"Fill out your application form accurately with the required details. Ensure a smooth process for your learner's license application."
		],
		[
			"STEP 3",
			"Generate PSID",
			"After submitting your application, a unique PSID (Public Service Identifier) will be generated for reference and processing."
		],
		[
			"STEP 4",
			"Payment Confirmation",
			"Following the submission, once the payment for your application is successfully processed, you'll receive a payment confirmation."
		],
		[
			"STEP 5",
			"Print Learner",
			"Obtain a physical copy of your learner's license by printing it directly from our system. Get ready to hit the road safely!"
		]
	],
	regular: [
		[
			"STEP 1",
			"Create Account & Login",
			"Begin your driving journey: sign up or log in to access our online platform. Streamlined processes await, so start today for a smoother path to driving."
		],
		[
			"STEP 2",
			"Fill Application Form",
			"Fill out your application form accurately with the required details. Ensure a smooth process for your learner's license application."
		],
		[
			"STEP 3",
			"Generate PSID",
			"After submitting your application, a unique PSID (Public Service Identifier) will be generated for reference and processing."
		],
		[
			"STEP 4",
			"Payment Confirmation",
			"Following the submission, once the payment for your application is successfully processed, you'll receive a payment confirmation."
		],
		[
			"STEP 5",
			"Approval",
			"Subsequently, your application undergoes an administrative review. Upon approval, you'll be notified that your application has been approved by the administration."
		],
		[
			"STEP 6",
			"Processing & Dispatch",
			"Finally, once approved, your driving license application will be processed and dispatched to you accordingly."
		]
	]
};
function FaqList() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-white",
		children: FAQ.map((item, index) => {
			const on = open === index;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-line last:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-3 px-4 py-3 text-left text-sm font-semibold",
					onClick: () => setOpen(on ? -1 : index),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: item.q
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: on ? "⌃" : "⌄"
						})
					]
				}), on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc px-10 pb-3 text-sm text-ink/80",
					children: item.a.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
				}) : null]
			}, item.q);
		})
	});
}
function Steps({ kind }) {
	const rows = STEPS[kind];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-6 sm:grid-cols-2",
		children: rows.map(([step, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-12 shrink-0 place-items-center rounded-full bg-leaf-soft text-leaf",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-black",
					children: step.replace("STEP ", "")
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-black tracking-wide text-leaf",
					children: step
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-black",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-ink/70",
					children: body
				})
			] })]
		}, step))
	});
}
function Home({ onOpen, onMenu }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-[#f4f6f8] font-[Poppins,system-ui,sans-serif] text-[#1a1a1a]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "brand-marquee banner-flow",
				"aria-label": "DLIMS, Dastak and Traffic Police Punjab",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "brand-track",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand-slide flex items-center justify-between gap-2 px-3 text-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] leading-tight font-bold",
									children: [
										"All DLIMS",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"services are",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Powered by"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl leading-none font-black tracking-wide",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mark-dlims",
											children: "DLIMS"
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mark-ver",
											children: "2.1"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-right text-[11px] leading-tight font-black",
									children: [
										"ONE WINDOW",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"FOR ALL",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"SERVICES"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "brand-slide flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/dastak-cut.png",
								alt: "Dastak",
								className: "h-14 object-contain"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand-slide flex items-center justify-center gap-2 px-3 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/tp-badge-cut.png",
								alt: "",
								className: "h-12 object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs leading-tight font-black",
								children: [
									"TRAFFIC POLICE",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"PUNJAB"
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "banner-edge" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-start justify-between border-b border-[#e8ece9] bg-[#f4f6f8] px-3 pt-2.5 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://dlims.punjab.gov.pk/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/dlims-online.jpg",
								alt: "",
								className: "h-10 w-10 object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "block text-[15px] leading-none font-extrabold text-[#1b7a3d]",
								children: "DLIMS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block max-w-[88px] text-[7px] leading-tight font-semibold text-[#2e8b4f]",
								children: ["Driving License Information ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#e67e22]",
									children: "Management System"
								})]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-9 w-px shrink-0 bg-[#c5cfc8]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://dastak.punjab.gov.pk/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/dastak-page.jpg",
								alt: "Dastak",
								className: "h-10 w-[92px] object-contain"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-9 w-px shrink-0 bg-[#c5cfc8]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "https://trafficpolice.punjab.gov.pk/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/tp-badge-cut.png",
								alt: "",
								className: "h-10 w-10 object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[8px] leading-tight font-extrabold text-[#1b7a3d]",
								children: [
									"TRAFFIC",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"POLICE",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"PUNJAB"
								]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-label": "Menu",
					onClick: onMenu,
					className: "mt-4 grid shrink-0 gap-[5px] p-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-[2.5px] w-[22px] rounded bg-[#1a1a1a]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-[2.5px] w-[22px] rounded bg-[#1a1a1a]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-[2.5px] w-[22px] rounded bg-[#1a1a1a]" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-wrap justify-center gap-1.5 border-b border-[#dce8e0] bg-[#f0f7f2] px-3 py-2",
				children: [["https://dastak.punjab.gov.pk/", "Dastak Portal"], ["https://trafficpolice.punjab.gov.pk/", "Traffic Police Punjab"]].map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "rounded-full border border-[#c5e0cc] bg-white px-2.5 py-1 text-[10px] font-semibold text-[#157a38]",
					children: label
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-5 pt-7 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-[22px] leading-tight font-extrabold tracking-wide text-[#111] uppercase",
						children: ["ONE WINDOW FOR ALL", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: "DRIVING LICENSE SERVICES"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen("services"),
						className: "mx-auto mt-4 grid size-[92px] place-items-center rounded-2xl bg-[#1b9e4b] text-center leading-tight font-extrabold text-white shadow-md",
						children: [
							"DLIMS",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"2.1"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-bold tracking-[1.5px] text-[#222] uppercase",
						children: "TRAFFIC POLICE PUNJAB"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/dlims/portrait-page.jpg",
						alt: "",
						className: "mx-auto mt-4 h-64 w-[220px] object-contain object-bottom"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-4 pt-4 pb-7 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-[15px] font-bold tracking-[4px] text-[#b8962e]",
						children: "FEATURES"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/dlims/dastak-page.jpg",
						alt: "Dastak",
						className: "mx-auto mb-4 h-14 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpen("apply-learner"),
								className: "w-[92px] rounded-[14px] border border-[#e6ebe8] bg-[#f4f6f5] px-2 py-3 text-[11px] leading-tight font-semibold shadow-sm",
								children: [
									"Learner",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"License"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpen("apply-regular"),
								className: "w-[92px] rounded-[14px] border border-[#5a5f5c] bg-[#5a5f5c] px-2 py-3 text-[11px] leading-tight font-semibold text-white shadow-sm",
								children: [
									"Regular",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"License"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpen("apply-international"),
								className: "w-[92px] rounded-[14px] border border-[#e6ebe8] bg-[#f4f6f5] px-2 py-3 text-[11px] leading-tight font-semibold shadow-sm",
								children: [
									"International",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"License"
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "relative overflow-hidden bg-gradient-to-b from-[#1f9e4a] to-[#157a38] px-4 pt-8 pb-8 text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 -top-4 h-8 rounded-b-[100%] bg-[#f4f6f8]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative grid gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/dlims/dastak-cut.png",
						alt: "Dastak",
						className: "mb-2 h-12 object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[280px] text-[11px] leading-relaxed",
						children: "The Driving License Information Management System (DLIMS) is an integrated component of the Government of Punjab’s Dastak – One Window for all Government Services which securely carries out all DLIMS processes including form submission, verification, payment, and card tracking."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-semibold",
						children: "For driving license-related queries, please contact us at"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-1 text-[11.5px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Emergency Number: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "15" })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Phone Number: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline",
								href: "tel:+924299202892",
								children: "042-99202892"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Email: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline",
								href: "mailto:info@dlims.punjab.gov.pk",
								children: "info@dlims.punjab.gov.pk"
							})] })
						]
					})] })]
				})]
			})
		]
	});
}
function KindSwitch({ kind, setKind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-4 flex justify-center gap-2",
		children: [
			["learner", "Learner License"],
			["regular", "Regular License"],
			["international", "International License"]
		].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setKind(id),
			className: `rounded-md px-3 py-2 text-xs font-bold ${kind === id ? "bg-leaf text-white" : "border border-line bg-white"}`,
			children: label
		}, id))
	});
}
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl overflow-hidden rounded-3xl bg-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "bg-[#1f9e4a] px-4 py-5 text-center text-4xl font-black text-white",
				children: "About DLIMS"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-center gap-4 px-4 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/dlims/dlims-online.jpg",
						alt: "DLIMS 2.1",
						className: "h-16 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/dlims/dastak-page.jpg",
						alt: "Dastak",
						className: "h-14 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2 text-xs font-black text-[#1b7a3d]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/dlims/tp-badge-cut.png",
								alt: "",
								className: "h-14 object-contain"
							}),
							"TRAFFIC",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"POLICE",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"PUNJAB"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 pb-4 text-sm leading-relaxed",
				children: "The Driving License Information Management System (DLIMS 2.1) is a unified platform integrated with the Government of Punjab's Dastak initiative — a One Window portal for all essential government services. Powered collaboratively by DLIMS, Maryam Ki Dastak (Doorstep Delivery of Services), and Traffic Police Punjab, this system securely streamlines the entire driving license lifecycle. It provides citizens with hassle-free access to digital form submission, automated document verification, secure payment processing, and real-time card tracking."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "inline-block rounded-lg bg-[#163a86] px-3 py-1 text-sm font-bold text-white",
					children: "DLIMS 2.1 Key Features:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 space-y-3 text-sm",
					children: [
						["1. Unified Service Delivery", "یہ سسٹم مریم کی دستک اور ٹریفک پولیس پنجاب کے اشتراک سے کام کرتا ہے تاکہ شہریوں کو ایک ہی پلیٹ فارم پر تمام سروسز مل سکیں۔"],
						["2. Digital Form Submission", "لرنر، ریگولر، رینیول، اور انٹرنیشنل ڈرائیونگ لائسنس کے لیے مکمل طور پر آن لائن اپلائی کرنے کی سہولت۔"],
						["3. Secure Payment Gateway", "فیس کی ادائیگی کے لیے پی ایس آئی ڈی کا فوری اجراء اور ڈیجیٹل ذرائع سے محفوظ ادائیگی کا نظام۔"],
						["4. Real-time Card Integration", "لائسنس کی منظوری، پرنٹنگ، اور ڈسپیچ سے لے کر ڈیلیوری تک کا لائیو سٹیٹس۔"],
						["6. Automated Verification", "شناختی کوائف اور میڈیکل فارمز کی تیز ترین اور خودکار تصدیق۔"],
						["7. Real-time Card Tracking", "کارڈ کی منظوری سے ڈیلیوری تک لائیو سٹیٹس چیک کرنے کا فیچر۔"],
						["8. Doorstep Delivery Integration", "دستک کے ذریعے لائسنس کی گھر کی دہلیز تک محفوظ ترسیل۔"]
					].map(([title, urdu]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-black text-[#157a38]",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-[Noto_Nastaliq_Urdu,serif] text-[15px] leading-8",
						dir: "rtl",
						children: urdu
					})] }, title))
				})]
			})
		]
	});
}
function How() {
	const [kind, setKind] = (0, import_react.useState)("learner");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-white p-4 md:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindSwitch, {
			kind,
			setKind
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Steps, { kind: kind === "learner" ? "learner" : "regular" })]
	});
}
function FaqPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-4 text-center text-3xl font-black text-leaf",
			children: "Frequently asked questions"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})]
	});
}
function MedicalForm() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl bg-white p-4 text-sm leading-relaxed text-ink md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-center text-2xl font-black",
				children: "FORM B"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs font-bold",
				children: "(SEE SECTION 7(3) AND SECTION (2))"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-center text-sm font-black",
				children: "NATIONAL IDENTITY CARD NUMBER"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdBoxes, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4",
				children: "Form of Medical Certificate in respect of application for a license to drive any transport vehicle or to drive any vehicle as paid employee or otherwise:"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-black",
				children: "TO BE FILLED IN BY A REGISTERED MEDICAL PRACTITIONER"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-3 list-decimal space-y-3 pl-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["What is apparent age of the applicant? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Is the applicant, to best of your judgment, subjected to epilepsy, vertigo, chronic ill-health likely to effect his/her efficiency? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Does the applicant suffer from any heart or lung disorder which might effect the performance of his/her duties as a driver? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"(A) Is there any defect of sightedness, if so, has it been corrected by using suitable spectacles? ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {}),
						"(B) Does the applicant suffer from a degree of deafness which would prevent his/her hearing of ordinary sound signals? ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Does the applicant have any deformity or loss of members, which effects the performance of his/her duties as a driver? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Does the applicant possess any evidence of being addicted to the excessive use of alcohol, tobacco or drugs? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["In your opinion, he/she is generally fit as regards (a) bodily in health, and (b) eyesight? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Marks of identification. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Blood Group ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4",
				children: [
					"I certify that to the best of my knowledge and belief the applicant ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block min-w-40 border-b border-ink" }),
					" is the person here as above described and that the attached photograph is a reasonably correct likeness."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid h-36 place-items-center border border-ink text-center text-xs font-bold",
					children: [
						"SPACE",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"FOR",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"PHOTOGRAPH"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["SIGNATURE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["NAME ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["R.M.P NO. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: "DOCTOR'S NATIONAL IDENTITY CARD NO."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdBoxes, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Date ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-center text-xs text-ink/70",
				children: "Print this form and have a registered medical practitioner complete it."
			})
		]
	});
}
function Line() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 block border-b border-ink/70" });
}
function IdBoxes() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 flex justify-center gap-0.5",
		children: [
			1,
			1,
			1,
			1,
			1,
			0,
			1,
			1,
			1,
			1,
			1,
			1,
			1,
			0,
			1
		].map((box, index) => box ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-5 border border-ink" }, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "px-0.5",
			children: "—"
		}, index))
	});
}
function Downloads() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-2 text-center text-3xl font-black",
				children: "Downloads"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-center text-sm text-ink/70",
				children: "Medical certificate Form B. Print it and have a registered doctor fill it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => window.print(),
				className: "mb-4 rounded-full bg-leaf px-5 py-2 text-sm font-bold text-white",
				children: "Print Form B"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MedicalForm, {})
		]
	});
}
var REGULAR = [
	[
		"M/Cycle",
		"50",
		"450",
		"480",
		"930"
	],
	[
		"Rickshaw",
		"100",
		"400",
		"480",
		"880"
	],
	[
		"Car/Jeep",
		"15",
		"1350",
		"480",
		"1830"
	],
	[
		"Tractor Agri",
		"50",
		"950",
		"480",
		"1430"
	],
	[
		"Tractor Commercial",
		"100",
		"1400",
		"480",
		"1880"
	],
	[
		"LTV",
		"15",
		"1850",
		"480",
		"2330"
	],
	[
		"Invalid Carriage",
		"0",
		"0",
		"480",
		"480"
	],
	[
		"M/Cycle+Car/Jeep",
		"200",
		"1350",
		"480",
		"1830"
	],
	[
		"M/Cycle+LTV",
		"200",
		"1850",
		"480",
		"2330"
	]
].map(([name, ...cells]) => ({
	name,
	cells: cells.map((n) => n === "0" ? "Rs. 0" : `Rs. ${n}`)
}));
var RENEW = [
	[
		"M/Cycle",
		"450",
		"225",
		"450",
		"1125",
		"480",
		"930"
	],
	[
		"Tractor Commercial",
		"1400",
		"700",
		"1400",
		"3500",
		"480",
		"1880"
	],
	[
		"Rickshaw",
		"400",
		"200",
		"400",
		"1000",
		"480",
		"880"
	],
	[
		"Car/Jeep",
		"1350",
		"675",
		"1350",
		"3375",
		"480",
		"1830"
	],
	[
		"M/Cycle+M/Car",
		"1350",
		"675",
		"1350",
		"3375",
		"480",
		"1830"
	],
	[
		"Agriculture",
		"1350",
		"675",
		"1350",
		"3375",
		"480",
		"1830"
	],
	[
		"LTV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"M/Cycle+LTV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"LTV + PSV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"M/Cycle+LTV+Trac Com",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"HTV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"M/Cycle+PSV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"HTV + PSV",
		"1850",
		"925",
		"1850",
		"4625",
		"480",
		"2330"
	],
	[
		"Tractor Agri",
		"980",
		"475",
		"950",
		"2375",
		"480",
		"1430"
	],
	[
		"Invalid Carriage",
		"Free",
		"Free",
		"Free",
		"Free",
		"480",
		"480"
	]
].map(([name, ...cells]) => ({
	name,
	cells: cells.map((n) => n === "Free" ? "Free" : `Rs. ${n}`)
}));
var DUPLICATE = [
	[
		"M/Cycle",
		"100",
		"480",
		"580"
	],
	[
		"Tractor Commercial",
		"100",
		"480",
		"580"
	],
	[
		"Rickshaw",
		"100",
		"480",
		"580"
	],
	[
		"Car/Jeep",
		"150",
		"480",
		"630"
	],
	[
		"M/Cycle+M/Car",
		"200",
		"480",
		"680"
	],
	[
		"Agriculture",
		"200",
		"480",
		"680"
	],
	[
		"LTV",
		"150",
		"480",
		"630"
	],
	[
		"M/Cycle+LTV",
		"200",
		"480",
		"680"
	],
	[
		"LTV + PSV",
		"200",
		"480",
		"680"
	],
	[
		"M/Cycle+LTV+Trac Com",
		"200",
		"480",
		"680"
	],
	[
		"HTV",
		"200",
		"480",
		"680"
	],
	[
		"M/Cycle+PSV",
		"200",
		"480",
		"680"
	],
	[
		"HTV + PSV",
		"200",
		"480",
		"680"
	],
	[
		"Tractor Agri",
		"200",
		"480",
		"680"
	],
	[
		"Invalid Carriage",
		"Free",
		"480",
		"480"
	]
].map(([name, ...cells]) => ({
	name,
	cells: cells.map((n) => n === "Free" ? "Free" : `Rs. ${n}`)
}));
var INTL = [
	[
		"M/Cycle",
		"450",
		"480",
		"930",
		"1350",
		"1830"
	],
	[
		"Tractor Commercial",
		"1400",
		"480",
		"1880",
		"4200",
		"4680"
	],
	[
		"Rickshaw",
		"400",
		"480",
		"880",
		"1200",
		"1680"
	],
	[
		"Car/Jeep",
		"1350",
		"480",
		"1830",
		"4050",
		"4530"
	],
	[
		"M/Cycle+M/Car",
		"1350",
		"480",
		"1830",
		"4050",
		"4530"
	],
	[
		"Agriculture",
		"1350",
		"480",
		"1830",
		"4050",
		"4530"
	],
	[
		"LTV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"M/Cycle+LTV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"LTV + PSV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"M/Cycle+LTV+Trac Com",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"HTV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"M/Cycle+PSV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"HTV + PSV",
		"1850",
		"480",
		"2330",
		"5550",
		"6030"
	],
	[
		"Tractor Agri",
		"950",
		"480",
		"1430",
		"2850",
		"3330"
	],
	[
		"Invalid Carriage",
		"Free",
		"480",
		"480",
		"Free",
		"480"
	]
].map(([name, ...cells]) => ({
	name,
	cells: cells.map((n) => n === "Free" ? "Free" : `Rs. ${n}`)
}));
function CatIcon({ name }) {
	const n = name.toLowerCase();
	const Icon = n.includes("invalid") ? Accessibility : n.includes("htv") || n.includes("bus") || n.includes("trac com") ? Bus : n.includes("tractor") || n.includes("agri") ? Tractor : n.includes("rick") ? Truck : n.includes("cycle") && !n.includes("car") && !n.includes("ltv") ? Bike : Car;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className: "size-4 shrink-0",
		"aria-hidden": "true"
	});
}
function Table({ title, note, headers, rows, id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-ink/60",
				children: "Fee Structure"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-center text-xl font-black",
				children: title
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-ink/60",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 overflow-x-auto rounded-xl border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-leaf text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: headers.map((head) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-bold",
							children: head
						}, head)) })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "flex items-center gap-2 px-2 py-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatIcon, { name: row.name }), row.name]
						}), row.cells.map((cell, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 whitespace-nowrap",
							children: cell
						}, index))]
					}, row.name)) })]
				})
			})
		]
	});
}
function Fees({ onDuplicate }) {
	const [tab, setTab] = (0, import_react.useState)("regular");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("regular"),
					className: `rounded-md px-4 py-2 text-sm font-bold ${tab === "regular" ? "bg-leaf text-white" : "border border-line bg-white"}`,
					children: "Regular License"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("international"),
					className: `rounded-md px-4 py-2 text-sm font-bold ${tab === "international" ? "bg-leaf text-white" : "border border-line bg-white"}`,
					children: "International License"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-4 max-w-md rounded-xl border border-line bg-white px-4 py-3 text-center text-sm",
				children: "In any combination the fee of highest fee category will be applicable"
			}),
			tab === "regular" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					id: "regular-fee",
					title: "Regular License",
					note: "The fee are applicable for one year",
					headers: [
						"Category",
						"Test Fee",
						"Fee After Passing Test",
						"Courier Fee",
						"Total Fee (Excluding Test Fee)"
					],
					rows: REGULAR
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-ink/60",
					children: "Candidate can make regular license for the period of 1 year, 2 years, 3 years, 4 years, or 5 years max."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					id: "renew",
					title: "Regular License Renewal",
					headers: [
						"Category",
						"Renewal Fee (1 Year)",
						"Fine (1 to 3 M)",
						"Fine (3 M to 1 Y)",
						"Fine (1 Year)",
						"Courier Fee",
						"Total (without fine)"
					],
					rows: RENEW
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-ink/60",
					children: "If a person applies for renewal and the original license is not available, the duplicate fee will be added."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					id: "duplicate",
					title: "Duplicate License",
					headers: [
						"Category",
						"Duplicate Fee",
						"Courier Fee",
						"Total"
					],
					rows: DUPLICATE
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#renew",
						className: "rounded-full bg-leaf-soft px-6 py-2 text-sm font-bold text-leaf",
						children: "Renew"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onDuplicate,
						className: "rounded-full border border-leaf px-6 py-2 text-sm font-bold text-leaf",
						children: "Duplicate"
					})]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					id: "intl",
					title: "International License",
					headers: [
						"Category",
						"Fee per Annum",
						"Courier Fee",
						"Total Fee",
						"Total Fee (3 Years)",
						"Total"
					],
					rows: INTL
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-ink/60",
					children: "If a person applies for renewal and the original license is not available, the duplicate fee will be added."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-leaf px-6 py-2 text-sm font-bold text-leaf",
						children: "Renew International License"
					})
				})
			] })
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative mt-10 overflow-hidden bg-leaf px-4 pt-16 pb-8 text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 -top-8 h-16 rounded-[100%] bg-[#f7f8f6]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-5xl gap-8 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/dlims/dastak-cut.png",
				alt: "Dastak",
				className: "h-16 object-contain"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-sm leading-relaxed",
				children: "The Driving License Information Management System (DLIMS) is an integrated component of the Government of Punjab's Dastak — One Window for all Government Services which securely carries out all DLIMS processes including form submission, verification, payment, and card tracking."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:text-right",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: "For driving license-related queries, please contact us at"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: "Emergency Number: 15"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Phone Number: 042-99202892"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Email: info@dlims.punjab.gov.pk"
					})
				]
			})]
		})]
	});
}
var KEY = "dlims-demo-v1";
var SESSION = "dlims-session";
var ADMIN_USER = "support.dlims.punjab.pk@gmail.com";
var ADMIN_PASS = "Pakistan123$#@";
var DEMO_ID = "demo-check-license";
var demoLicense = () => ({
	id: DEMO_ID,
	cnic: "3520200000001",
	name: "DEMO CHECK LICENSE",
	father: "DEMO FATHER NAME",
	dob: "1990-01-15",
	district: "FAISALABAD",
	address: "DEMO ADDRESS, FAISALABAD",
	phone: "03000000000",
	email: "demo@dlims.local",
	photo: "",
	licenseNo: "FD-00-00001",
	kind: "REGULAR",
	vehicles: "M/CYCLE, CAR",
	issueDate: "2025-05-13",
	validFrom: "2025-05-13",
	validTo: "2027-05-13",
	status: "Valid",
	trackingNo: "PK000000001",
	printedOn: "2025-05-14",
	dispatchOn: "2025-05-16",
	handler: "Pakistan Post"
});
function withDemo(data) {
	if (data.licenses.some((item) => item.id === DEMO_ID)) return data;
	return {
		...data,
		licenses: [demoLicense(), ...data.licenses]
	};
}
function empty() {
	return withDemo({
		accounts: [],
		licenses: [],
		requests: []
	});
}
function read() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return empty();
		const parsed = JSON.parse(raw);
		return withDemo({
			accounts: parsed.accounts ?? [],
			licenses: parsed.licenses ?? [],
			requests: parsed.requests ?? []
		});
	} catch {
		return empty();
	}
}
var db = typeof localStorage === "undefined" ? empty() : read();
var listeners = /* @__PURE__ */ new Set();
function emit() {
	try {
		localStorage.setItem(KEY, JSON.stringify(db));
	} catch {}
	listeners.forEach((listener) => listener());
}
function subscribe(listener) {
	listeners.add(listener);
	const onStorage = (event) => {
		if (event.key === KEY) {
			db = read();
			listener();
		}
	};
	window.addEventListener("storage", onStorage);
	return () => {
		listeners.delete(listener);
		window.removeEventListener("storage", onStorage);
	};
}
function getDB() {
	return db;
}
var SERVER_DB = empty();
function useDB() {
	return (0, import_react.useSyncExternalStore)(subscribe, getDB, () => SERVER_DB);
}
var sessionCache = null;
var sessionRaw;
function getSession() {
	try {
		const raw = sessionStorage.getItem(SESSION);
		if (raw === sessionRaw) return sessionCache;
		sessionRaw = raw;
		sessionCache = raw ? JSON.parse(raw) : null;
		return sessionCache;
	} catch {
		return null;
	}
}
function useSession() {
	return (0, import_react.useSyncExternalStore)((listener) => {
		window.addEventListener("dlims-session", listener);
		return () => window.removeEventListener("dlims-session", listener);
	}, getSession, () => null);
}
function setSession(session) {
	if (session) sessionStorage.setItem(SESSION, JSON.stringify(session));
	else sessionStorage.removeItem(SESSION);
	window.dispatchEvent(new Event("dlims-session"));
}
function logout() {
	setSession(null);
}
function login(user, password) {
	const id = user.trim();
	if (id.toLowerCase() === "support.dlims.punjab.pk@gmail.com" && password === "Pakistan123$#@") {
		setSession({
			role: "admin",
			name: "Admin"
		});
		return { ok: true };
	}
	const account = db.accounts.find((item) => item.email.toLowerCase() === id.toLowerCase() || item.cnic === id.replace(/\D/g, ""));
	if (!account || account.password !== password) return {
		ok: false,
		message: "Login details do not match."
	};
	if (account.status === "pending") return {
		ok: false,
		message: "Sign up is waiting for admin verification."
	};
	if (account.status === "rejected") return {
		ok: false,
		message: "This sign up was not accepted."
	};
	setSession({
		role: "user",
		name: account.name,
		cnic: account.cnic
	});
	return { ok: true };
}
function signUp(input) {
	const cnic = input.cnic.replace(/\D/g, "");
	if (db.accounts.some((item) => item.cnic === cnic || item.email.toLowerCase() === input.email.toLowerCase())) return "This CNIC or email is already registered.";
	db = {
		...db,
		accounts: [{
			...input,
			cnic,
			id: crypto.randomUUID(),
			status: "pending",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...db.accounts]
	};
	emit();
	return "";
}
function saveRequest(input) {
	const request = {
		...input,
		cnic: input.cnic.replace(/\D/g, ""),
		id: crypto.randomUUID(),
		status: "new",
		psid: "",
		payment: "Unpaid",
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	db = {
		...db,
		requests: [request, ...db.requests || []]
	};
	emit();
	return request.id;
}
function updateRequest(id, patch) {
	db = {
		...db,
		requests: db.requests.map((item) => item.id === id ? {
			...item,
			...patch
		} : item)
	};
	emit();
}
function setAccountStatus(id, status) {
	db = {
		...db,
		accounts: db.accounts.map((item) => item.id === id ? {
			...item,
			status
		} : item)
	};
	emit();
}
function setAccountFee(id, feeConfirmed) {
	db = {
		...db,
		accounts: db.accounts.map((item) => item.id === id ? {
			...item,
			feeConfirmed
		} : item)
	};
	emit();
}
function setLicenseFee(id, feeConfirmed) {
	db = {
		...db,
		licenses: db.licenses.map((item) => item.id === id ? {
			...item,
			feeConfirmed
		} : item)
	};
	emit();
	const record = db.licenses.find((item) => item.id === id);
	if (record) syncLicense(record);
}
function syncLicense(record) {
	saveSharedLicense({ data: {
		user: ADMIN_USER,
		password: ADMIN_PASS,
		record
	} }).catch(() => {});
}
function saveLicense(record) {
	const index = db.licenses.findIndex((item) => item.id === record.id);
	const licenses = [...db.licenses];
	if (index >= 0) licenses[index] = record;
	else licenses.unshift(record);
	db = {
		...db,
		licenses
	};
	emit();
	syncLicense(record);
}
function replaceLicenses(records) {
	if (records.length === 0) return;
	db = {
		...db,
		licenses: records
	};
	emit();
}
async function loadSharedLicenses() {
	const records = await listSharedLicenses({ data: {
		user: ADMIN_USER,
		password: ADMIN_PASS
	} });
	replaceLicenses(records);
	return records;
}
function removeLicense(id) {
	db = {
		...db,
		licenses: db.licenses.filter((item) => item.id !== id)
	};
	emit();
	removeSharedLicense({ data: {
		user: ADMIN_USER,
		password: ADMIN_PASS,
		id
	} }).catch(() => {});
}
function blankLicense(seed) {
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return {
		id: crypto.randomUUID(),
		cnic: "",
		name: "",
		father: "",
		dob: "",
		district: "FAISALABAD",
		address: "",
		phone: "",
		email: "",
		photo: "",
		licenseNo: "",
		kind: "REGULAR",
		vehicles: "M/CYCLE",
		issueDate: today,
		validFrom: today,
		validTo: today,
		status: "Valid",
		trackingNo: "",
		printedOn: "",
		dispatchOn: "",
		handler: "Pakistan Post",
		...seed
	};
}
var TITLES = {
	learner: {
		title: "Learner License",
		hint: "New learner driving licence application."
	},
	regular: {
		title: "Regular License Renewal",
		hint: "Renew an existing regular driving licence."
	},
	international: {
		title: "International License",
		hint: "Apply for an international driving licence."
	}
};
function Services({ onApply }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-full items-center justify-between rounded-[28px] bg-[#e2b423] px-6 py-5 text-left text-2xl font-black text-[#1a1a1a]",
			children: ["Apply Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-14 place-items-center rounded-2xl bg-[#f3d56a] text-3xl",
				children: "↗"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-4",
			children: [
				{
					kind: "learner",
					label: "LEARNER LICENSE"
				},
				{
					kind: "regular",
					label: "REGULAR LICENSE"
				},
				{
					kind: "international",
					label: "INTERNATIONAL LICENSE"
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onApply(item.kind),
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-8 place-items-center rounded-full bg-[#1f9e4a] text-sm font-black text-white",
					children: "✓"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1 rounded-full border border-[#e6e6e6] bg-white px-5 py-3 text-center text-sm font-black tracking-wide text-[#157a38] shadow-sm",
					children: item.label
				})]
			}, item.kind))
		})]
	});
}
function ApplyForm({ kind }) {
	const copy = TITLES[kind];
	const [message, setMessage] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") || "").trim();
		const father = String(data.get("father") || "").trim();
		const cnic = String(data.get("cnic") || "").replace(/\D/g, "");
		const dob = String(data.get("dob") || "").trim();
		const phone = String(data.get("phone") || "").trim();
		const address = String(data.get("address") || "").trim();
		if (!name || !father || cnic.length < 11 || !dob || !phone || !address) {
			setMessage("Name, father name, CNIC, date of birth, phone and address are required.");
			setRef("");
			return;
		}
		const id = saveRequest({
			category: kind,
			name: name.toUpperCase(),
			father: father.toUpperCase(),
			cnic,
			dob,
			phone,
			email: String(data.get("email") || "").trim(),
			district: String(data.get("district") || "FAISALABAD").trim().toUpperCase(),
			address: address.toUpperCase(),
			licenseNo: String(data.get("licenseNo") || "").trim().toUpperCase(),
			vehicle: String(data.get("vehicle") || "").trim()
		});
		setMessage("");
		setRef(id.slice(0, 8).toUpperCase());
		event.currentTarget.reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mx-auto max-w-lg space-y-3 rounded-3xl bg-white p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-black tracking-[0.2em] text-[#b8962e]",
				children: "APPLICATION"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-black text-leaf",
				children: copy.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-ink/70",
				children: [copy.hint, " After submit, the request goes to the admin panel."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "name",
				label: "Full name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "father",
				label: "Father / husband name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "cnic",
				label: "CNIC",
				inputMode: "numeric"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "dob",
				label: "Date of birth",
				placeholder: "YYYY-MM-DD"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "phone",
				label: "Phone",
				inputMode: "tel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "email",
				label: "Email",
				type: "email",
				required: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "district",
				label: "District",
				defaultValue: "FAISALABAD"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "address",
				label: "Address"
			}),
			kind === "learner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-semibold",
				children: ["Vehicle", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					name: "vehicle",
					className: "mt-1 w-full rounded-xl border border-line px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "M/Cycle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Car" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "M/Cycle + Car" })
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				name: "licenseNo",
				label: kind === "regular" ? "Current licence number" : "Regular licence number"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "w-full rounded-full bg-[#157a38] py-3 font-bold text-white",
				children: "Submit request"
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-[#fff4f4] px-3 py-2 text-sm text-[#9b1c1c]",
				children: message
			}) : null,
			ref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-[#eef8f1] px-3 py-2 text-sm font-semibold text-[#157a38]",
				children: [
					"Request sent to admin. Reference ",
					ref,
					"."
				]
			}) : null
		]
	});
}
function Field({ name, label, type = "text", required = true, placeholder, defaultValue, inputMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-semibold",
		children: [
			label,
			required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[#d10000]",
				children: " *"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name,
				type,
				required,
				placeholder,
				defaultValue,
				inputMode,
				className: "mt-1 w-full rounded-xl border border-line px-3 py-2 font-normal"
			})
		]
	});
}
var input$1 = "w-full rounded-lg border border-line bg-white px-3 py-3 text-sm";
function LoginForm({ onAdmin }) {
	const session = useSession();
	const [user, setUser] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const result = login(user, password);
		setMessage(result.ok ? "" : result.message);
		if (result.ok && getSession()?.role === "admin") onAdmin?.();
	}
	if (session) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "Login" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center font-semibold",
				children: ["Signed in as ", session.name]
			}),
			session.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onAdmin,
				className: "mt-4 w-full rounded-full bg-[#157a38] py-3 font-bold text-white",
				children: "Open admin panel"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: logout,
				className: "mt-4 w-full rounded-full bg-leaf py-3 font-bold text-white",
				children: "Log out"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "Login" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-bold",
						children: ["CNIC or email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${input$1} mt-1`,
							value: user,
							onChange: (event) => setUser(event.target.value),
							autoComplete: "username",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-bold",
						children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${input$1} mt-1`,
							type: "password",
							value: password,
							onChange: (event) => setPassword(event.target.value),
							autoComplete: "current-password",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "w-full rounded-full bg-[#f5c400] py-3 font-bold text-white",
						children: "Login"
					})
				]
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: message })
			}) : null
		]
	});
}
function SignUpForm() {
	const [message, setMessage] = (0, import_react.useState)("");
	const [photo, setPhoto] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		const data = new FormData(event.currentTarget);
		const error = signUp({
			name: String(data.get("name") || ""),
			father: String(data.get("father") || ""),
			cnic: String(data.get("cnic") || ""),
			dob: String(data.get("dob") || ""),
			gender: String(data.get("gender") || ""),
			phone: String(data.get("phone") || ""),
			email: String(data.get("email") || ""),
			password: String(data.get("password") || ""),
			district: String(data.get("district") || ""),
			address: String(data.get("address") || ""),
			licenseType: String(data.get("licenseType") || ""),
			photo
		});
		setMessage(error || "Sign up sent. Admin will verify this request before login is allowed.");
		if (!error) event.currentTarget.reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, { title: "Sign up" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Full name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "name",
									required: true,
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Father / husband name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "father",
									required: true,
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["CNIC", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "cnic",
									required: true,
									inputMode: "numeric",
									placeholder: "Without dashes",
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Date of birth", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "dob",
									required: true,
									type: "date",
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Gender", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "gender",
									className: `${input$1} mt-1`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Male" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Female" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Other" })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Phone", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "phone",
									required: true,
									inputMode: "tel",
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold sm:col-span-2",
								children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "email",
									required: true,
									type: "email",
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "password",
									required: true,
									type: "password",
									minLength: 6,
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["License type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "licenseType",
									className: `${input$1} mt-1`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Learner" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Regular" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "International" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Duplicate" })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold",
								children: ["District", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "district",
									required: true,
									defaultValue: "FAISALABAD",
									className: `${input$1} mt-1`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold sm:col-span-2",
								children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "address",
									required: true,
									className: `${input$1} mt-1`
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-bold",
						children: ["Photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: `${input$1} mt-1`,
							onChange: (event) => {
								const file = event.target.files?.[0];
								if (!file) return;
								const reader = new FileReader();
								reader.onload = () => setPhoto(String(reader.result || ""));
								reader.readAsDataURL(file);
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "w-full rounded-full bg-leaf py-3 font-bold text-white",
						children: "Create account"
					})
				]
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: message })
			}) : null
		]
	});
}
var input = "w-full rounded-lg border border-line bg-white px-3 py-2 text-sm";
var PANELS = [
	{
		id: "requests",
		label: "Requests"
	},
	{
		id: "live",
		label: "Live"
	},
	{
		id: "ecard",
		label: "E-Card"
	},
	{
		id: "regular",
		label: "Regular"
	},
	{
		id: "edit",
		label: "Edit"
	},
	{
		id: "status",
		label: "Status"
	},
	{
		id: "fee",
		label: "Fee"
	},
	{
		id: "learner",
		label: "Learner"
	}
];
function readUpload(file, done) {
	if (file.type === "application/pdf") {
		const reader = new FileReader();
		reader.onload = () => done(String(reader.result || ""));
		reader.readAsDataURL(file);
		return;
	}
	readImage(file, done);
}
function readImage(file, done) {
	const reader = new FileReader();
	reader.onload = () => {
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, 900 / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
			done(canvas.toDataURL("image/jpeg", .72));
		};
		img.src = String(reader.result || "");
	};
	reader.readAsDataURL(file);
}
function AdminDesk({ onLeave }) {
	const session = useSession();
	const db = useDB();
	const [panel, setPanel] = (0, import_react.useState)("requests");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [sharedNote, setSharedNote] = (0, import_react.useState)("Cards are saved in the shared database.");
	(0, import_react.useEffect)(() => {
		if (!session || session.role !== "admin") return;
		let live = true;
		loadSharedLicenses().then(() => {
			if (live) setSharedNote("Shared database connected. A card saved here shows on other phones.");
		}).catch(() => {
			if (live) setSharedNote("Shared database is not reachable yet. This phone still keeps a local copy.");
		});
		return () => {
			live = false;
		};
	}, [session]);
	if (!session || session.role !== "admin") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-md rounded-2xl bg-white p-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-black",
			children: "This page is not public."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onLeave,
			className: "mt-4 rounded-full bg-leaf px-5 py-2 text-sm font-bold text-white",
			children: "Back"
		})]
	});
	const pending = db.accounts.filter((item) => item.status === "pending").length;
	const review = db.accounts.filter((item) => item.status === "review").length;
	const approved = db.accounts.filter((item) => item.status === "accepted").length;
	const rejected = db.accounts.filter((item) => item.status === "rejected").length;
	const fees = db.accounts.filter((item) => item.feeConfirmed).length + db.licenses.filter((item) => item.feeConfirmed).length;
	const ecards = db.licenses.filter((item) => item.ecard).length;
	const permits = db.licenses.filter((item) => item.learnerPermit || item.kind.toUpperCase().includes("LEARN")).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-lg space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-black text-leaf",
						children: "Admin panel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold text-ink/60",
						children: ADMIN_USER
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-semibold text-[#157a38]",
						children: sharedNote
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						logout();
						onLeave();
					},
					className: "rounded-full border border-line px-3 py-1 text-sm font-bold",
					children: "Log out"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PANELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPanel(item.id),
					className: `rounded-full px-3 py-1 text-xs font-bold ${panel === item.id ? "bg-[#157a38] text-white" : "bg-white"}`,
					children: item.label
				}, item.id))
			}),
			panel === "requests" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [(db.requests || []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "No service requests yet."
				}) : null, (db.requests || []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-white p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-ink/60",
							children: [
								item.category,
								" · ",
								item.cnic,
								" · ",
								item.phone
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-ink/60",
							children: [
								item.licenseNo ? `Licence ${item.licenseNo} · ` : "",
								item.vehicle,
								" · ",
								item.status,
								" · ",
								item.payment
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-[#e0a020] px-3 py-1 text-xs font-bold",
									onClick: () => updateRequest(item.id, { status: "processing" }),
									children: "Start processing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-leaf px-3 py-1 text-xs font-bold text-white",
									onClick: () => updateRequest(item.id, { status: "approved" }),
									children: "Approve"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-[#c51616] px-3 py-1 text-xs font-bold text-white",
									onClick: () => updateRequest(item.id, { status: "rejected" }),
									children: "Reject"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-[#163a86] px-3 py-1 text-xs font-bold text-white",
									onClick: () => updateRequest(item.id, {
										psid: item.psid || String(Date.now()).slice(0, 17),
										payment: "Unpaid"
									}),
									children: item.psid ? `PSID ${item.psid}` : "Issue PSID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-pill px-3 py-1 text-xs font-bold",
									onClick: () => updateRequest(item.id, { payment: item.payment === "Paid" ? "Unpaid" : "Paid" }),
									children: item.payment === "Paid" ? "Mark unpaid" : "Mark paid"
								})
							]
						})
					]
				}, item.id))]
			}) : null,
			panel === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [[
					["Service requests", (db.requests || []).length],
					["Applications", db.accounts.length],
					["Pending", pending],
					["In review", review],
					["Approved", approved],
					["Rejected", rejected],
					["Licenses", db.licenses.length],
					["Fees confirmed", fees],
					["E-cards", ecards],
					["Learner permits", permits]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-white p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-bold tracking-wide text-ink/50 uppercase",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-black text-leaf",
						children: value
					})]
				}, String(label))), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "col-span-2 text-xs font-semibold text-[#157a38]",
					children: "Live — numbers change as soon as a record is saved on this device."
				})]
			}) : null,
			panel === "status" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [db.accounts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "No applications yet."
				}) : null, db.accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-white p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: account.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-ink/60",
							children: [
								account.cnic,
								" · ",
								account.licenseType,
								" · ",
								account.status,
								account.feeConfirmed ? " · fee confirmed" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-[#e0a020] px-3 py-1 text-xs font-bold",
									onClick: () => setAccountStatus(account.id, "review"),
									children: "Review"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-leaf px-3 py-1 text-xs font-bold text-white",
									onClick: () => setAccountStatus(account.id, "accepted"),
									children: "Approve"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full bg-[#c51616] px-3 py-1 text-xs font-bold text-white",
									onClick: () => setAccountStatus(account.id, "rejected"),
									children: "Reject"
								})
							]
						})
					]
				}, account.id))]
			}) : null,
			panel === "fee" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [db.accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: account.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-ink/60",
						children: "Application"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `rounded-full px-3 py-1 text-xs font-bold ${account.feeConfirmed ? "bg-leaf text-white" : "bg-pill"}`,
						onClick: () => setAccountFee(account.id, !account.feeConfirmed),
						children: account.feeConfirmed ? "Confirmed" : "Confirm fee"
					})]
				}, account.id)), db.licenses.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-ink/60",
						children: record.licenseNo
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `rounded-full px-3 py-1 text-xs font-bold ${record.feeConfirmed ? "bg-leaf text-white" : "bg-pill"}`,
						onClick: () => setLicenseFee(record.id, !record.feeConfirmed),
						children: record.feeConfirmed ? "Confirmed" : "Confirm fee"
					})]
				}, record.id))]
			}) : null,
			panel === "ecard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadList, {
				kind: "ecard",
				records: db.licenses
			}) : null,
			panel === "learner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UploadList, {
				kind: "learner",
				records: db.licenses
			}) : null,
			panel === "regular" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "rounded-full bg-[#157a38] px-4 py-2 text-sm font-bold text-white",
				onClick: () => setEditing(blankLicense({ kind: "REGULAR" })),
				children: "Add regular license"
			}) }) : null,
			panel === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm font-bold text-leaf",
					onClick: () => setEditing(blankLicense()),
					children: "New record"
				}) }), db.licenses.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2 rounded-2xl bg-white p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: record.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-ink/60",
						children: [
							record.licenseNo,
							" · ",
							record.status
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-bold text-[#163a86]",
							onClick: () => setEditing(record),
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-bold text-star",
							onClick: () => removeLicense(record.id),
							children: "Delete"
						})]
					})]
				}, record.id))]
			}) : null,
			editing && (panel === "regular" || panel === "edit") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseEditor, {
				record: editing,
				onClose: () => setEditing(null)
			}) : null
		]
	});
}
function UploadList({ kind, records }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "space-y-2",
		children: [records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "Save a license first, then upload here."
		}) : null, records.map((record) => {
			const file = kind === "ecard" ? record.ecard : record.learnerPermit;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-white p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: record.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-ink/60",
						children: [
							record.cnic,
							" · ",
							record.licenseNo
						]
					}),
					file ? file.startsWith("data:application/pdf") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs font-bold text-[#163a86]",
						children: "PDF uploaded"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: file,
						alt: "",
						className: "mt-2 max-h-40 rounded-lg"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: kind === "ecard" ? "image/*,application/pdf" : "image/*",
						className: `${input} mt-2`,
						onChange: (event) => {
							const picked = event.target.files?.[0];
							if (!picked) return;
							const save = (url) => saveLicense(kind === "ecard" ? {
								...record,
								ecard: url
							} : {
								...record,
								learnerPermit: url,
								kind: record.kind || "LEARNER"
							});
							if (kind === "ecard") readUpload(picked, save);
							else readImage(picked, save);
						}
					})
				]
			}, record.id);
		})]
	});
}
function LicenseEditor({ record, onClose }) {
	const [draft, setDraft] = (0, import_react.useState)(record);
	function set(key, value) {
		setDraft((current) => ({
			...current,
			[key]: value
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		saveLicense({
			...draft,
			cnic: draft.cnic.replace(/\D/g, "")
		});
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "space-y-2 rounded-2xl bg-white p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-black",
				children: "Full license details"
			}),
			[
				{
					key: "name",
					label: "Name"
				},
				{
					key: "father",
					label: "Father / husband"
				},
				{
					key: "cnic",
					label: "CNIC"
				},
				{
					key: "dob",
					label: "Date of birth"
				},
				{
					key: "district",
					label: "District"
				},
				{
					key: "address",
					label: "Address"
				},
				{
					key: "phone",
					label: "Phone"
				},
				{
					key: "email",
					label: "Email"
				},
				{
					key: "licenseNo",
					label: "License number"
				},
				{
					key: "kind",
					label: "Type"
				},
				{
					key: "vehicles",
					label: "Allowed vehicles"
				},
				{
					key: "issueDate",
					label: "Issue date"
				},
				{
					key: "validFrom",
					label: "Valid from"
				},
				{
					key: "validTo",
					label: "Valid to"
				},
				{
					key: "status",
					label: "Status"
				},
				{
					key: "trackingNo",
					label: "Tracking number"
				},
				{
					key: "printedOn",
					label: "Printed on"
				},
				{
					key: "dispatchOn",
					label: "Dispatch on"
				},
				{
					key: "handler",
					label: "Delivery handler"
				}
			].map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs font-bold",
				children: [field.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: `${input} mt-1`,
					value: String(draft[field.key] ?? ""),
					onChange: (event) => set(field.key, event.target.value)
				})]
			}, field.key)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-xs font-bold",
				children: ["Profile photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/*",
					className: `${input} mt-1`,
					onChange: (event) => {
						const file = event.target.files?.[0];
						if (!file) return;
						readImage(file, (url) => set("photo", url));
					}
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "rounded-full bg-leaf px-4 py-2 text-sm font-bold text-white",
					children: "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "rounded-full bg-pill px-4 py-2 text-sm font-bold",
					children: "Cancel"
				})]
			})
		]
	});
}
var TEXT = [
	{
		id: "home",
		label: "Home"
	},
	{
		id: "about",
		label: "About us"
	},
	{
		id: "how",
		label: "How it works"
	},
	{
		id: "faq",
		label: "FAQ"
	},
	{
		id: "downloads",
		label: "Downloads"
	},
	{
		id: "fees",
		label: "Fee Structure"
	}
];
var PILLS = [
	{
		id: "elicense",
		label: "e-License"
	},
	{
		id: "track",
		label: "Track Application"
	},
	{
		id: "verify",
		label: "Verify License"
	}
];
function DlimsApp() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [applyKind, setApplyKind] = (0, import_react.useState)("learner");
	const session = useSession();
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = menu ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [menu]);
	function go(next) {
		if (next === "apply-learner" || next === "apply-regular" || next === "apply-international") {
			setApplyKind(next.slice(6));
			setTab("apply");
		} else setTab(next);
		setMenu(false);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}
	const form = tab === "track" || tab === "elicense" || tab === "verify" || tab === "duplicate" || tab === "login" || tab === "signup" || tab === "admin" || tab === "apply" || tab === "services";
	const home = tab === "home";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: home ? "relative mx-auto min-h-dvh max-w-[480px] bg-[#f4f6f8] shadow-[0_0_40px_rgba(0,0,0,.08)]" : "relative min-h-dvh bg-[#f4f6f8]",
		children: [
			home ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "brand-marquee banner-flow",
						"aria-label": "DLIMS, Dastak and Traffic Police Punjab",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand-track",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "brand-slide flex items-center justify-between gap-2 px-3 text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] leading-tight font-bold sm:text-xs",
											children: [
												"All DLIMS",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
												"services are",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
												"Powered by"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-2xl leading-none font-black tracking-wide sm:text-4xl",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mark-dlims",
													children: "DLIMS"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mark-ver",
													children: "2.1"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-right text-[11px] leading-tight font-black sm:text-sm",
											children: [
												"ONE WINDOW",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
												"FOR ALL",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
												"SERVICES"
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "brand-slide flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/dlims/dastak-cut.png",
										alt: "Dastak",
										className: "h-16 object-contain"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "brand-slide flex items-center justify-center gap-3 px-3 text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/dlims/tp-badge-cut.png",
										alt: "",
										className: "h-14 object-contain"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm leading-tight font-black sm:text-lg",
										children: [
											"TRAFFIC POLICE",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											"PUNJAB"
										]
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "banner-edge" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-b border-line/70 bg-[#f4f6f8]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-6xl items-center gap-2 px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => go("home"),
									className: "flex shrink-0 items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/dlims/dlims-online.jpg",
										alt: "",
										className: "h-12 w-12 object-contain"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-lg leading-none font-black tracking-tight text-leaf",
										children: "DLIMS"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block max-w-28 text-[7px] leading-tight font-bold text-[#c4922a]",
										children: "Driving License Information Management System"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-10 w-px shrink-0 bg-line" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/dlims/tp-badge-cut.png",
									alt: "",
									className: "h-12 shrink-0 object-contain"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] leading-tight font-black tracking-wide text-leaf sm:text-sm",
									children: [
										"TRAFFIC POLICE",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"PUNJAB"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
									className: "ml-auto hidden items-center gap-3 text-xs font-bold lg:flex",
									children: [
										TEXT.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => go(link.id),
											className: tab === link.id ? "text-[#e0a020]" : "text-ink",
											children: link.label
										}, link.id)),
										PILLS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => go(link.id),
											className: `rounded-full px-3 py-1 ${tab === link.id ? "bg-[#f5a623] text-white" : "border border-line bg-white"}`,
											children: link.label
										}, link.id)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => go("login"),
											className: "rounded-full border border-line px-3 py-1",
											children: session ? session.name : "Login"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => go("signup"),
											className: "rounded-full bg-leaf px-3 py-1 text-white",
											children: "Sign up"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ml-auto grid size-11 place-items-center rounded-xl border border-ink/30 bg-[#f4f6f8] lg:hidden",
									"aria-label": "Open menu",
									onClick: () => setMenu(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex w-5 flex-col gap-[5px]",
										"aria-hidden": "true",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-[2px] bg-ink" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-[2px] bg-ink" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-[2px] bg-ink" })
										]
									})
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: home ? "" : `mx-auto max-w-6xl px-4 py-6 ${form ? "pb-16" : ""}`,
				children: [
					tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home, {
						onOpen: (id) => go(id),
						onMenu: () => setMenu(true)
					}) : null,
					tab === "services" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, { onApply: (kind) => go(`apply-${kind}`) }) : null,
					tab === "apply" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyForm, { kind: applyKind }) : null,
					tab === "about" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}) : null,
					tab === "how" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(How, {}) : null,
					tab === "faq" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqPage, {}) : null,
					tab === "downloads" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Downloads, {}) : null,
					tab === "fees" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fees, { onDuplicate: () => go("duplicate") }) : null,
					tab === "elicense" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ELicense, {}) : null,
					tab === "track" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Track, {})
					}) : null,
					tab === "verify" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verify, {})
					}) : null,
					tab === "duplicate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DuplicateForm, { onBack: () => go("fees") }) : null,
					tab === "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginForm, { onAdmin: () => go("admin") }) : null,
					tab === "signup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignUpForm, {}) : null,
					tab === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDesk, { onLeave: () => go("home") }) : null
				]
			}),
			form || home ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setMenu(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "absolute inset-y-0 left-0 flex w-64 flex-col bg-[#f7f8fa] px-5 py-8",
					children: [
						TEXT.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go(link.id),
							className: "min-h-11 text-left text-base font-medium",
							children: link.label
						}, link.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go("elicense"),
								className: "rounded-full bg-pill px-4 py-2 text-sm font-semibold",
								children: "e-License"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go("track"),
								className: "rounded-full bg-pill px-4 py-2 text-sm font-semibold",
								children: "Track Application"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => go("verify"),
							className: "mt-3 w-fit rounded-full bg-[#f5c400] px-5 py-2 text-sm font-bold text-white",
							children: "Verify License"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-2 border-t border-line pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go("login"),
								className: "block min-h-11 text-left text-base font-bold",
								children: session ? session.name : "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => go("signup"),
								className: "block min-h-11 text-left text-base font-bold",
								children: "Sign up"
							})]
						})
					]
				})]
			}) : null
		]
	});
}
var SplitComponent = DlimsApp;
//#endregion
export { SplitComponent as component };
