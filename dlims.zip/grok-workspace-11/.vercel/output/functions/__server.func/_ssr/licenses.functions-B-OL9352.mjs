import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/licenses.functions-B-OL9352.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_licenses_default = "create table if not exists licenses (\n  id text primary key,\n  cnic text not null default '',\n  name text not null default '',\n  father text not null default '',\n  dob text not null default '',\n  district text not null default '',\n  address text not null default '',\n  phone text not null default '',\n  email text not null default '',\n  photo text not null default '',\n  license_no text not null default '',\n  kind text not null default 'REGULAR',\n  vehicles text not null default '',\n  issue_date text not null default '',\n  valid_from text not null default '',\n  valid_to text not null default '',\n  status text not null default 'Valid',\n  tracking_no text not null default '',\n  printed_on text not null default '',\n  dispatch_on text not null default '',\n  handler text not null default '',\n  ecard text not null default '',\n  learner_permit text not null default '',\n  fee_confirmed boolean not null default false,\n  updated_at timestamptz not null default now()\n);\n\ncreate index if not exists licenses_cnic_idx on licenses (cnic);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_licenses.sql": _0002_licenses_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var ADMIN_USER = "support.dlims.punjab.pk@gmail.com";
var ADMIN_PASS = "Pakistan123$#@";
function clip(value, max) {
	return String(value ?? "").slice(0, max);
}
function toRecord(row) {
	return {
		id: row.id,
		cnic: row.cnic,
		name: row.name,
		father: row.father,
		dob: row.dob,
		district: row.district,
		address: row.address,
		phone: row.phone,
		email: row.email,
		photo: row.photo,
		licenseNo: row.license_no,
		kind: row.kind,
		vehicles: row.vehicles,
		issueDate: row.issue_date,
		validFrom: row.valid_from,
		validTo: row.valid_to,
		status: row.status,
		trackingNo: row.tracking_no,
		printedOn: row.printed_on,
		dispatchOn: row.dispatch_on,
		handler: row.handler,
		ecard: row.ecard || void 0,
		learnerPermit: row.learner_permit || void 0,
		feeConfirmed: Boolean(row.fee_confirmed)
	};
}
function isAdmin(user, password) {
	return String(user ?? "").trim().toLowerCase() === ADMIN_USER && String(password ?? "") === ADMIN_PASS;
}
async function ensureDemo(sql) {
	if ((await sql`select id from licenses where id = 'demo-check-license' limit 1`).length > 0) return;
	await sql`
    insert into licenses (
      id, cnic, name, father, dob, district, address, phone, email, photo,
      license_no, kind, vehicles, issue_date, valid_from, valid_to, status,
      tracking_no, printed_on, dispatch_on, handler
    ) values (
      'demo-check-license', '3520200000001', 'DEMO CHECK LICENSE', 'DEMO FATHER NAME',
      '1990-01-15', 'FAISALABAD', 'DEMO ADDRESS, FAISALABAD', '03000000000',
      'demo@dlims.local', '', 'FD-00-00001', 'REGULAR', 'M/CYCLE, CAR',
      '2025-05-13', '2025-05-13', '2027-05-13', 'Valid', 'PK000000001',
      '2025-05-14', '2025-05-16', 'Pakistan Post'
    )
    on conflict (id) do nothing
  `;
}
var lookupLicense_createServerFn_handler = createServerRpc({
	id: "68e54590d80575eb23fbef189c5868d6a4c0b0bb5115b6a89f2143b1863918a7",
	name: "lookupLicense",
	filename: "src/lib/licenses.functions.ts"
}, (opts) => lookupLicense.__executeServer(opts));
var lookupLicense = createServerFn({ method: "POST" }).validator((input) => ({
	cnic: String(input?.cnic ?? "").replace(/\D/g, ""),
	dob: String(input?.dob ?? "").trim(),
	licenseNo: String(input?.licenseNo ?? "").replace(/\s/g, "").toLowerCase()
})).handler(lookupLicense_createServerFn_handler, async ({ data }) => {
	if (data.cnic.length < 5) return null;
	const sql = await getSql();
	await ensureDemo(sql);
	const match = (await sql`select * from licenses where cnic = ${data.cnic}`).find((row) => {
		if (data.dob && row.dob && row.dob !== data.dob) return false;
		if (data.licenseNo && row.license_no.replace(/\s/g, "").toLowerCase() !== data.licenseNo) return false;
		return true;
	});
	return match ? toRecord(match) : null;
});
var listSharedLicenses_createServerFn_handler = createServerRpc({
	id: "787e4c45bd26ea737b1f795e45d5061c88de68c29ae2ba471160e0178b16898e",
	name: "listSharedLicenses",
	filename: "src/lib/licenses.functions.ts"
}, (opts) => listSharedLicenses.__executeServer(opts));
var listSharedLicenses = createServerFn({ method: "POST" }).validator((input) => input).handler(listSharedLicenses_createServerFn_handler, async ({ data }) => {
	if (!isAdmin(data?.user, data?.password)) throw new Error("Not allowed");
	const sql = await getSql();
	await ensureDemo(sql);
	return (await sql`select * from licenses order by updated_at desc`).map(toRecord);
});
var saveSharedLicense_createServerFn_handler = createServerRpc({
	id: "e4cced8738d1180f6a77949e6513d1a9fc8bbdaceed4c3fcc4c56386656e0b2c",
	name: "saveSharedLicense",
	filename: "src/lib/licenses.functions.ts"
}, (opts) => saveSharedLicense.__executeServer(opts));
var saveSharedLicense = createServerFn({ method: "POST" }).validator((input) => input).handler(saveSharedLicense_createServerFn_handler, async ({ data }) => {
	if (!isAdmin(data?.user, data?.password)) throw new Error("Not allowed");
	const record = data?.record;
	if (!record?.id) throw new Error("License is missing");
	const ecard = clip(record.ecard, 18e5);
	const photo = clip(record.photo, 18e5);
	const permit = clip(record.learnerPermit, 18e5);
	if (record.ecard && ecard.length < String(record.ecard).length || record.photo && photo.length < String(record.photo).length) throw new Error("That picture is too large. Use a smaller photo.");
	await (await getSql())`
      insert into licenses (
        id, cnic, name, father, dob, district, address, phone, email, photo,
        license_no, kind, vehicles, issue_date, valid_from, valid_to, status,
        tracking_no, printed_on, dispatch_on, handler, ecard, learner_permit, fee_confirmed, updated_at
      ) values (
        ${clip(record.id, 80)},
        ${clip(String(record.cnic).replace(/\D/g, ""), 20)},
        ${clip(record.name, 160)},
        ${clip(record.father, 160)},
        ${clip(record.dob, 20)},
        ${clip(record.district, 80)},
        ${clip(record.address, 400)},
        ${clip(record.phone, 30)},
        ${clip(record.email, 160)},
        ${photo},
        ${clip(record.licenseNo, 40)},
        ${clip(record.kind, 40)},
        ${clip(record.vehicles, 160)},
        ${clip(record.issueDate, 20)},
        ${clip(record.validFrom, 20)},
        ${clip(record.validTo, 20)},
        ${clip(record.status, 40)},
        ${clip(record.trackingNo, 40)},
        ${clip(record.printedOn, 20)},
        ${clip(record.dispatchOn, 20)},
        ${clip(record.handler, 80)},
        ${ecard},
        ${permit},
        ${Boolean(record.feeConfirmed)},
        now()
      )
      on conflict (id) do update set
        cnic = excluded.cnic,
        name = excluded.name,
        father = excluded.father,
        dob = excluded.dob,
        district = excluded.district,
        address = excluded.address,
        phone = excluded.phone,
        email = excluded.email,
        photo = excluded.photo,
        license_no = excluded.license_no,
        kind = excluded.kind,
        vehicles = excluded.vehicles,
        issue_date = excluded.issue_date,
        valid_from = excluded.valid_from,
        valid_to = excluded.valid_to,
        status = excluded.status,
        tracking_no = excluded.tracking_no,
        printed_on = excluded.printed_on,
        dispatch_on = excluded.dispatch_on,
        handler = excluded.handler,
        ecard = excluded.ecard,
        learner_permit = excluded.learner_permit,
        fee_confirmed = excluded.fee_confirmed,
        updated_at = now()
    `;
	return { ok: true };
});
var removeSharedLicense_createServerFn_handler = createServerRpc({
	id: "3cf8ec612c2fa355f8ee6c7fa62ee7d620dbde8672ed6649686e06b5425f4f64",
	name: "removeSharedLicense",
	filename: "src/lib/licenses.functions.ts"
}, (opts) => removeSharedLicense.__executeServer(opts));
var removeSharedLicense = createServerFn({ method: "POST" }).validator((input) => input).handler(removeSharedLicense_createServerFn_handler, async ({ data }) => {
	if (!isAdmin(data?.user, data?.password)) throw new Error("Not allowed");
	const id = clip(data?.id, 80);
	if (!id || id === "demo-check-license") throw new Error("This record cannot be removed");
	await (await getSql())`delete from licenses where id = ${id}`;
	return { ok: true };
});
//#endregion
export { listSharedLicenses_createServerFn_handler, lookupLicense_createServerFn_handler, removeSharedLicense_createServerFn_handler, saveSharedLicense_createServerFn_handler };
