//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RT7I2cmR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DDguRs0i.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DDguRs0i.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BTtKBmFx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
